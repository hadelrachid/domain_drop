<?php

declare(strict_types=1);

namespace DomainSystem\Plugins\domain_drop\Controllers;

use DomainSystem\Core\Contracts\ResponseInterface;
use DomainSystem\Core\Contracts\SessionManagerInterface;
use DomainSystem\Core\Http\Request;
use DomainSystem\Core\Http\Response;
use DomainSystem\Core\Http\Responses\JsonResponse;
use DomainSystem\Core\Http\Responses\ViewResponse;
use DomainSystem\Plugins\domain_drop\Contracts\AliExpressApiClientInterface;
use DomainSystem\Plugins\domain_drop\Contracts\CurrencyConverterInterface;
use DomainSystem\Plugins\domain_drop\Contracts\DropshipCatalogRepositoryInterface;
use DomainSystem\Plugins\domain_drop\Contracts\DropshipCustomerRepositoryInterface;
use DomainSystem\Plugins\domain_drop\Contracts\DropshipDisputeRepositoryInterface;
use DomainSystem\Plugins\domain_drop\Contracts\ProductMediaSyncInterface;
use DomainSystem\Plugins\domain_drop\Contracts\ProductMiningServiceInterface;
use DomainSystem\Plugins\domain_drop\DTO\DropshipProductDto;
use DomainSystem\Plugins\domain_drop\Services\OrderSlaProgressService;
use DomainSystem\Plugins\domain_drop\Services\SellerMediationService;
use Throwable;

/**
 * Controlador Administrativo do Hub DomainDrop (SRP / DIP).
 */
class DropshipAdminController
{
    private string $configFile;
    private ?string $basePathRoot = null;

    public function __construct(
        private readonly DropshipCatalogRepositoryInterface $catalogRepo,
        private readonly ProductMiningServiceInterface $miningService,
        private readonly CurrencyConverterInterface $currencyConverter,
        private readonly SessionManagerInterface $session,
        private readonly ?\DomainSystem\Plugins\domain_drop\Contracts\DropshipOrderRepositoryInterface $orderRepo = null,
        private readonly ?ProductMediaSyncInterface $mediaSync = null,
        ?string $basePath = null,
        private readonly ?DropshipCustomerRepositoryInterface $customerRepo = null,
        private readonly ?DropshipDisputeRepositoryInterface $disputeRepo = null,
        private readonly ?OrderSlaProgressService $slaService = null,
        private readonly ?SellerMediationService $mediationService = null,
        private readonly ?AliExpressApiClientInterface $apiClient = null,
        private readonly ?\DomainSystem\Plugins\domain_drop\Contracts\DemandMetricsRepositoryInterface $metricsRepo = null,
        private readonly ?\DomainSystem\Plugins\domain_drop\Contracts\DemandLogStorageInterface $logStorage = null,
        private readonly ?\DomainSystem\Plugins\domain_drop\Services\DropshipCustomerNotificationService $notificationService = null,
        private readonly ?\DomainSystem\Plugins\domain_drop\Contracts\AliExpressAuthorizationUrlBuilderInterface $authUrlBuilder = null,
        private readonly ?\DomainSystem\Plugins\domain_drop\Contracts\TokenExchangeServiceInterface $tokenExchangeService = null,
        private readonly ?\DomainSystem\Plugins\domain_drop\Services\PricingConfigUpdater $pricingUpdater = null
    ) {
        $root = $basePath ?? (defined('DOMAIN_SYSTEM_ROOT') ? DOMAIN_SYSTEM_ROOT : dirname(__DIR__, 4));
        $this->basePathRoot = $root;
        $this->configFile = $root . '/config/plugins/domain_drop.json';
    }

    public function index(Request $request): ResponseInterface
    {
        $baseUrl = defined('BASE_URL') ? rtrim(BASE_URL, '/') : '';
        $category = (string)$request->input('category', '');
        $search = (string)$request->input('q', '');
        $status = trim((string)$request->input('status', ''));
        $page = max(1, (int)$request->input('page', 1));
        $perPage = 48; // 48 produtos por página (grade equilibrada para 2, 3 e 4 colunas, sem sobrar itens órfãos)

        $criteria = [];
        if ($category !== '') {
            $criteria['category'] = $category;
        }
        if ($search !== '') {
            $criteria['search'] = $search;
        }
        if ($status !== '' && in_array($status, ['published', 'draft', 'quarantine', 'review'], true)) {
            $criteria['status'] = ($status === 'quarantine' || $status === 'review') ? 'draft' : $status;
        }

        $totalCount = $this->catalogRepo->count($criteria);
        $totalAll = $this->catalogRepo->count();
        $totalPublished = $this->catalogRepo->count(['status' => 'published']);
        $totalDraft = $this->catalogRepo->count(['status' => 'draft']);

        $totalPages = max(1, (int)ceil($totalCount / $perPage));
        if ($page > $totalPages && $totalCount > 0) {
            $page = $totalPages;
        }
        $offset = ($page - 1) * $perPage;

        $products = $this->catalogRepo->list($criteria, $perPage, $offset);
        $categories = $this->catalogRepo->getCategories();
        $rate = $this->currencyConverter->getExchangeRate('USD', 'BRL');
        $config = $this->loadConfig();
        $cycleInfo = $this->miningService->getDailyCycleInfo();

        $flash = $this->session->getFlash();
        $flashMsg = $flash['msg'] ?? null;
        $flashType = $flash['type'] ?? null;

        ob_start();
        $csrfToken = (string)$this->session->getCsrfToken();
        include dirname(__DIR__) . '/views/admin/index.php';
        $content = ob_get_clean();

        return new ViewResponse($content ?: '');
    }

    public function mine(Request $request): ResponseInterface
    {
        $baseUrl = defined('BASE_URL') ? rtrim(BASE_URL, '/') : '';
        $isAjax = $this->isAjaxOrJson($request);

        if (!$this->verifyCsrf($request)) {
            if ($isAjax) {
                return new Response(json_encode(['success' => false, 'error' => 'Token de segurança expirado.']), 403, ['Content-Type' => 'application/json']);
            }
            $this->session->setFlash('error', 'Token de segurança expirado.');
            return Response::redirect($baseUrl . '/admin/dropship');
        }

        $category = trim((string)$request->input('category', 'Moda, Roupas & Vestuário'));
        if ($category === '') {
            $category = 'Moda, Roupas & Vestuário';
        }
        $limit = max(1, min(100, (int)$request->input('limit', 10)));
        $sort = (string)$request->input('sort', 'volume_desc');
        $replaceCatalog = (bool)$request->input('replace_catalog', false);
        $warehouseOrigin = strtoupper(trim((string)$request->input('warehouse_origin', 'ALL')));
        if (!in_array($warehouseOrigin, ['ALL', 'BR', 'CN'], true)) {
            $warehouseOrigin = 'ALL';
        }
        $sendToQuarantine = (bool)$request->input('quarantine', false);

        try {
            if ($replaceCatalog) {
                $this->catalogRepo->clearAll(preserveOrdered: true);
            }
            $mined = $this->miningService->mineTrendingProducts($category, $limit, true, $sort, $warehouseOrigin);
            if ($sendToQuarantine) {
                $minedIds = array_filter(array_map(fn($p) => (int)($p->id ?? 0), $mined));
                if (!empty($minedIds)) {
                    $this->catalogRepo->batchUpdateStatus($minedIds, 'draft');
                }
            } else {
                $this->catalogRepo->publishAll();
            }
            $count = count($mined);

            if ($count === 0) {
                $warnMsg = "⚠️ Nenhum produto encontrado para '{$category}' com os filtros selecionados (Reputação: {$sort}, Entreposto: {$warehouseOrigin}). Tente alterar para Entreposto 'Global' ou selecionar outra categoria.";
                if ($isAjax) {
                    return new Response(json_encode([
                        'success'     => false,
                        'warning'     => true,
                        'count'       => 0,
                        'mined_count' => 0,
                        'category'    => $category,
                        'message'     => $warnMsg,
                        'error'       => $warnMsg,
                    ]), 200, ['Content-Type' => 'application/json']);
                }
                $this->session->setFlash('warning', $warnMsg);
                return Response::redirect($baseUrl . '/admin/dropship');
            }

            $msg = $sendToQuarantine
                ? "🛡️ Mineração concluída com sucesso! {$count} produtos da categoria '{$category}' minerados e enviados para QUARENTENA / REVISÃO MANUAL antes de subirem para o site."
                : "🚀 Mineração concluída com sucesso! {$count} produtos da categoria '{$category}' minerados e ativos para venda no site.";

            if ($isAjax) {
                return new Response(json_encode([
                    'success'     => true,
                    'count'       => $count,
                    'mined_count' => $count,
                    'category'    => $category,
                    'message'     => $msg,
                ]), 200, ['Content-Type' => 'application/json']);
            }

            $this->session->setFlash('success', $msg);
        } catch (Throwable $e) {
            $errMsg = "Falha ao minerar produtos: " . $e->getMessage();
            if ($isAjax) {
                return new Response(json_encode([
                    'success' => false,
                    'error'   => $errMsg,
                ]), 500, ['Content-Type' => 'application/json']);
            }
            $this->session->setFlash('error', $errMsg);
        }

        return Response::redirect($baseUrl . '/admin/dropship');
    }

    public function importUrl(Request $request): ResponseInterface
    {
        $baseUrl = defined('BASE_URL') ? rtrim(BASE_URL, '/') : '';

        if (!$this->verifyCsrf($request)) {
            $this->session->setFlash('error', 'Token de segurança expirado.');
            return Response::redirect($baseUrl . '/admin/dropship');
        }

        $urlOrId = trim((string)$request->input('product_url_or_id', ''));
        if ($urlOrId === '') {
            $this->session->setFlash('error', 'Informe a URL ou ID do produto no AliExpress.');
            return Response::redirect($baseUrl . '/admin/dropship');
        }

        try {
            $product = $this->miningService->importSingleProduct($urlOrId);
            $this->session->setFlash('success', "✅ Produto '{$product->title}' importado com sucesso!");
        } catch (Throwable $e) {
            $this->session->setFlash('error', "Falha na importação: " . $e->getMessage());
        }

        return Response::redirect($baseUrl . '/admin/dropship');
    }

    public function importBrowserSource(Request $request): ResponseInterface
    {
        $baseUrl = defined('BASE_URL') ? rtrim(BASE_URL, '/') : '';

        if (!$this->verifyCsrf($request)) {
            $this->session->setFlash('error', 'Token de segurança expirado.');
            return Response::redirect($baseUrl . '/admin/dropship');
        }

        $rawSource = trim((string)$request->input('raw_source', ''));
        $category = trim((string)$request->input('category', ''));
        $category = $category !== '' ? $category : null;

        if ($rawSource === '') {
            $this->session->setFlash('error', 'Cole o código-fonte HTML ou JSON do produto na caixa de texto.');
            return Response::redirect($baseUrl . '/admin/dropship');
        }

        try {
            $product = $this->miningService->importFromBrowserSource($rawSource, $category);
            $this->session->setFlash('success', "✅ Produto '{$product->title}' importado com sucesso a partir do navegador!");
        } catch (Throwable $e) {
            $this->session->setFlash('error', "Falha ao processar código do produto: " . $e->getMessage());
        }

        return Response::redirect($baseUrl . '/admin/dropship');
    }

    /**
     * Download direto do vídeo do produto em MP4 (SRP / Streaming limpo).
     * Permite que o administrador baixe o criativo oficial em alta resolução
     * para veiculação de anúncios em redes sociais (TikTok, Reels, Facebook Ads, WhatsApp).
     */
    public function downloadVideo(Request $request): ResponseInterface
    {
        $id = (int)$request->input('id', 0);
        $urlParam = trim((string)$request->input('url', ''));
        $baseUrl = defined('BASE_URL') ? rtrim(BASE_URL, '/') : '';

        $videoUrl = '';
        $slug = 'produto';

        if ($urlParam !== '' && (filter_var($urlParam, FILTER_VALIDATE_URL) || str_starts_with($urlParam, '//'))) {
            $videoUrl = str_starts_with($urlParam, '//') ? ('https:' . $urlParam) : $urlParam;
        }

        if ($videoUrl === '' && $id > 0) {
            $product = $this->catalogRepo->findById($id);
            if ($product !== null) {
                $slug = $product->slug ?: 'produto';
                $videoUrl = (string)($product->attributes['video_url'] ?? '');
                if ($videoUrl === '' && !empty($product->description)) {
                    if (preg_match('/<source\s+src="([^"]+\.mp4[^"]*)"/i', $product->description, $mVid)) {
                        $videoUrl = $mVid[1];
                    }
                }
            }
        }

        if ($videoUrl === '') {
            $this->session->setFlash('error', 'Este produto não possui arquivo de vídeo cadastrado pelo fornecedor.');
            return Response::redirect($baseUrl . '/admin/dropship');
        }

        if (str_starts_with($videoUrl, '//')) {
            $videoUrl = 'https:' . $videoUrl;
        }

        $host = strtolower((string)parse_url($videoUrl, PHP_URL_HOST));
        $scheme = strtolower((string)parse_url($videoUrl, PHP_URL_SCHEME));
        if (!in_array($scheme, ['http', 'https'], true) || $host === '') {
            $this->session->setFlash('error', 'URL de vídeo com protocolo inválido.');
            return Response::redirect($baseUrl . '/admin/dropship');
        }

        // Bloqueia IPs privados e loopback (SSRF prevention)
        $ip = gethostbyname($host);
        if ($ip !== $host && !filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE)) {
            $this->session->setFlash('error', 'Acesso a endereços de rede privada não é permitido.');
            return Response::redirect($baseUrl . '/admin/dropship');
        }

        $cleanSlug = preg_replace('/[^a-zA-Z0-9_-]/', '-', $slug ?: 'produto') ?: 'video';
        $filename = "{$cleanSlug}-video.mp4";

        if (!headers_sent()) {
            header('Content-Type: video/mp4');
            header('Content-Disposition: attachment; filename="' . $filename . '"');
            header('Cache-Control: public, must-revalidate, max-age=0');
            header('Pragma: public');
        }

        // Streaming direto do vídeo via cURL sem estourar memória do PHP
        $ch = curl_init($videoUrl);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, false);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
        curl_setopt($ch, CURLOPT_PROTOCOLS, CURLPROTO_HTTP | CURLPROTO_HTTPS);
        curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36');
        curl_setopt($ch, CURLOPT_TIMEOUT, 120);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 2);
        curl_setopt($ch, CURLOPT_WRITEFUNCTION, function ($curl, $data) {
            echo $data;
            if (ob_get_level() > 0) {
                @ob_flush();
            }
            flush();
            return strlen($data);
        });
        curl_exec($ch);
        curl_close($ch);
        exit;
    }

    public function settings(Request $request): ResponseInterface
    {
        $baseUrl = defined('BASE_URL') ? rtrim(BASE_URL, '/') : '';
        $config = $this->loadConfig();
        $csrfToken = (string)$this->session->getCsrfToken();
        $rate = $this->currencyConverter->getExchangeRate('USD', 'BRL');

        $usageTracker = new \DomainSystem\Plugins\domain_drop\Services\ApiUsageTracker($this->basePathRoot);
        $apiUsage = $usageTracker->getUsageStats();

        $flash = $this->session->getFlash();
        $flashMsg = $flash['msg'] ?? null;
        $flashType = $flash['type'] ?? null;

        ob_start();
        include dirname(__DIR__) . '/views/admin/settings.php';
        $content = ob_get_clean();

        return new ViewResponse($content ?: '');
    }

    public function saveSettings(Request $request): ResponseInterface
    {
        $baseUrl = defined('BASE_URL') ? rtrim(BASE_URL, '/') : '';

        if (!$this->verifyCsrf($request)) {
            $this->session->setFlash('error', 'Token de segurança expirado.');
            return Response::redirect($baseUrl . '/admin/dropship/settings');
        }

        $config = $this->loadConfig();
        $config['app_key'] = trim((string)$request->input('app_key', $config['app_key'] ?? ''));
        $newSecret = trim((string)$request->input('app_secret', ''));
        if ($newSecret !== '' && !str_starts_with($newSecret, '***') && !str_starts_with($newSecret, '•••')) {
            $config['app_secret'] = $newSecret;
        }
        $newAccessToken = trim((string)$request->input('access_token', ''));
        if ($newAccessToken !== '' && !str_starts_with($newAccessToken, '***') && !str_starts_with($newAccessToken, '•••')) {
            $config['access_token'] = $newAccessToken;
        }

        $updater = $this->pricingUpdater ?? new \DomainSystem\Plugins\domain_drop\Services\PricingConfigUpdater();
        $config = $updater->updateFromRequest($config, $request);

        $originInput = strtoupper(trim((string)$request->input('mining_warehouse_origin', '')));
        if (in_array($originInput, ['ALL', 'BR', 'CN'], true)) {
            $config['mining_warehouse_origin'] = $originInput;
        }

        $this->saveConfig($config);
        $this->session->setFlash('success', 'Configurações da API salvas com sucesso!');

        return Response::redirect($baseUrl . '/admin/dropship/settings');
    }

    public function savePricing(Request $request): ResponseInterface
    {
        $baseUrl = defined('BASE_URL') ? rtrim(BASE_URL, '/') : '';

        if (!$this->verifyCsrf($request)) {
            $this->session->setFlash('error', 'Token de segurança expirado.');
            return Response::redirect($baseUrl . '/admin/dropship');
        }

        $config = $this->loadConfig();
        $updater = $this->pricingUpdater ?? new \DomainSystem\Plugins\domain_drop\Services\PricingConfigUpdater();
        $config = $updater->updateFromRequest($config, $request);

        $originInput = strtoupper(trim((string)$request->input('mining_warehouse_origin', '')));
        if (in_array($originInput, ['ALL', 'BR', 'CN'], true)) {
            $config['mining_warehouse_origin'] = $originInput;
        }

        $this->saveConfig($config);
        $this->session->setFlash('success', 'Estratégia de precificação e Sentinela de Volatilidade salvas com sucesso!');

        return Response::redirect($baseUrl . '/admin/dropship');
    }

    public function testConnection(Request $request): ResponseInterface
    {
        $baseUrl = defined('BASE_URL') ? rtrim(BASE_URL, '/') : '';

        if (!$this->verifyCsrf($request)) {
            if ($this->isAjaxOrJson($request)) {
                return new JsonResponse(['success' => false, 'status' => 'error', 'message' => 'Token de segurança expirado. Atualize a página e tente novamente.'], 403);
            }
            $this->session->setFlash('error', 'Token de segurança expirado.');
            return Response::redirect($baseUrl . '/admin/dropship/settings');
        }

        $config = $this->loadConfig();
        $appKey = trim((string)$request->input('app_key', $config['app_key'] ?? ''));
        $appSecret = trim((string)$request->input('app_secret', ''));
        if ($appSecret === '' || str_starts_with($appSecret, '***') || str_starts_with($appSecret, '•••')) {
            $appSecret = (string)($config['app_secret'] ?? '');
        }
        $accessToken = trim((string)$request->input('access_token', ''));
        if ($accessToken === '' || str_starts_with($accessToken, '***') || str_starts_with($accessToken, '•••')) {
            $accessToken = (string)($config['access_token'] ?? '');
        }
        $gatewayUrl = (string)($config['gateway_url'] ?? 'https://api-sg.aliexpress.com/sync');

        if ($appKey === '' || $appSecret === '') {
            $msg = '❌ O AppKey e o AppSecret são obrigatórios para testar a conexão com o servidor do AliExpress.';
            if ($this->isAjaxOrJson($request)) {
                return new JsonResponse(['success' => false, 'status' => 'error', 'message' => $msg], 400);
            }
            $this->session->setFlash('error', $msg);
            return Response::redirect($baseUrl . '/admin/dropship/settings');
        }

        try {
            $client = ($this->apiClient !== null && !$this->apiClient instanceof \DomainSystem\Plugins\domain_drop\Services\AliExpressApiClient)
                ? $this->apiClient
                : new \DomainSystem\Plugins\domain_drop\Services\AliExpressApiClient(
                    appKey: $appKey,
                    appSecret: $appSecret,
                    gatewayUrl: $gatewayUrl,
                    timeout: 10,
                    accessToken: $accessToken !== '' ? $accessToken : null
                );

            // Testa endpoint de detalhes de produto no gateway oficial do AliExpress
            $res = $client->getProductDetails('1005006093867086');

            // Sucesso Total
            $msg = "✔️ Conexão e sincronização 100% estabelecidas com o servidor do AliExpress! Protocolo HMAC-SHA256 validado e credenciais operantes.";
            if ($this->isAjaxOrJson($request)) {
                return new JsonResponse([
                    'success' => true,
                    'status'  => 'ok',
                    'message' => $msg,
                ]);
            }

            $this->session->setFlash('success', $msg);
            return Response::redirect($baseUrl . '/admin/dropship/settings');

        } catch (\DomainSystem\Plugins\domain_drop\Exceptions\AliExpressApiException $e) {
            $errCode = (string)$e->type;
            $errMsg = $e->getMessage();

            if (str_contains(strtolower($errMsg), 'access_token') || str_contains($errCode, 'MissingParameter') || str_contains($errCode, 'IllegalAccessToken') || str_contains($errCode, 'InvalidAccessToken') || str_contains($errCode, 'InvalidSession')) {
                $status = 'warning';
                $msg = "⚠️ Conexão física OK com o servidor do AliExpress (api-sg.aliexpress.com), mas a aplicação está em modo TEST ou o Access Token OAuth ainda não foi fornecido. Gere/cole o Access Token no campo abaixo ou clique em 'Apply Online' no portal openservice.aliexpress.com.";
            } elseif (str_contains($errCode, 'InvalidAppKey') || str_contains($errMsg, 'AppKey') || str_contains($errCode, 'IncompleteSignature') || str_contains($errCode, 'Signature')) {
                $status = 'error';
                $msg = "❌ Credenciais inválidas. O servidor do AliExpress rejeitou o AppKey ou AppSecret informados. Verifique se foram digitados corretamente ou gere novas credenciais no portal openservice.aliexpress.com.";
            } else {
                $status = 'warning';
                $msg = "⚠️ Resposta do Servidor AliExpress: {$errMsg}. Verifique as permissões da aplicação no painel de desenvolvedores.";
            }

            if ($this->isAjaxOrJson($request)) {
                return new JsonResponse([
                    'success' => false,
                    'status'  => $status,
                    'message' => $msg,
                    'code'    => $errCode,
                ]);
            }

            $this->session->setFlash($status === 'warning' ? 'warning' : 'error', $msg);
            return Response::redirect($baseUrl . '/admin/dropship/settings');
        } catch (Throwable $e) {
            $msg = "❌ Falha de rede ao conectar com o servidor do AliExpress: " . $e->getMessage() . ". Verifique se o servidor possui saída HTTPS para api-sg.aliexpress.com.";
            if ($this->isAjaxOrJson($request)) {
                return new JsonResponse(['success' => false, 'status' => 'error', 'message' => $msg], 500);
            }
            $this->session->setFlash('error', $msg);
            return Response::redirect($baseUrl . '/admin/dropship/settings');
        }
    }

    /**
     * Inicia o fluxo OAuth2 Server-side oficial do AliExpress Open Platform.
     */
    public function oauthAuthorize(Request $request): ResponseInterface
    {
        $baseUrl = defined('BASE_URL') ? rtrim(BASE_URL, '/') : '';
        $config = $this->loadConfig();
        $appKey = trim((string)($config['app_key'] ?? ''));
        $appSecret = trim((string)($config['app_secret'] ?? ''));

        if ($appKey === '' || $appSecret === '') {
            $this->session->setFlash('error', 'Informe e salve o AppKey e AppSecret antes de autorizar via OAuth2.');
            return Response::redirect($baseUrl . '/admin/dropship/settings');
        }

        $state = $this->generateSignedState($appSecret);
        $this->session->set('dropship_oauth_state', $state);

        $callbackUrl = $this->resolveOAuthCallbackUrl($baseUrl);
        $urlBuilder = $this->authUrlBuilder ?? new \DomainSystem\Plugins\domain_drop\Services\OAuth\AliExpressAuthorizationUrlBuilder($appKey);

        return Response::redirect($urlBuilder->build($callbackUrl, $state));
    }

    /**
     * Recebe o retorno OAuth2 (?code=...) do AliExpress e troca por access_token + refresh_token.
     */
    public function oauthCallback(Request $request): ResponseInterface
    {
        $baseUrl = defined('BASE_URL') ? rtrim(BASE_URL, '/') : '';
        $code = trim((string)$request->input('code', ''));
        $state = trim((string)$request->input('state', ''));
        $expectedState = (string)$this->session->get('dropship_oauth_state', '');
        $this->session->remove('dropship_oauth_state');

        $config = $this->loadConfig();
        $appKey = trim((string)($config['app_key'] ?? ''));
        $appSecret = trim((string)($config['app_secret'] ?? ''));

        $isLoggedIn = $this->session->has('user_id');
        $isSuccess = false;
        $errorMessage = null;
        $account = null;
        $expiresInDays = 30;

        // Validação estrita do State OAuth2 (Claude Audit Item 1)
        // Rejeita categoricamente requisições sem state, state forjado ou expirado.
        $isStateValid = false;
        if ($state !== '') {
            if ($expectedState !== '' && hash_equals($expectedState, $state)) {
                $isStateValid = true;
            } elseif ($appSecret !== '' && $this->verifySignedState($state, $appSecret)) {
                $isStateValid = true;
            }
        }

        if (!$isStateValid) {
            $errorMessage = 'Falha de segurança OAuth2 (state inválido, expirado ou ausente). Tente conectar novamente.';
        } elseif ($code === '') {
            $errDesc = trim((string)($request->input('error_description', '') ?: $request->input('error', 'Autorização cancelada ou código ausente.')));
            $errorMessage = 'AliExpress OAuth2 não retornou o código de autorização: ' . $errDesc;
        } else {
            $config = $this->loadConfig();
            $appKey = trim((string)($config['app_key'] ?? ''));
            $appSecret = trim((string)($config['app_secret'] ?? ''));

            if ($appKey === '' || $appSecret === '') {
                $errorMessage = 'AppKey ou AppSecret não configurados para concluir a troca de token OAuth2.';
            } else {
                try {
                    if ($this->tokenExchangeService !== null) {
                        $token = $this->tokenExchangeService->exchangeCode($code);
                    } elseif ($this->apiClient !== null && !$this->apiClient instanceof \DomainSystem\Plugins\domain_drop\Services\AliExpressApiClient) {
                        // Compatibilidade com Mocks de testes que injetam AliExpressApiClientInterface
                        $tokenData = $this->apiClient->createAccessToken($code);
                        $token = \DomainSystem\Plugins\domain_drop\ValueObjects\AliExpressToken::fromApiResponse($tokenData);
                        $tokenRepo = new \DomainSystem\Plugins\domain_drop\Services\OAuth\ConfigOAuthTokenRepository($this->basePathRoot);
                        $tokenRepo->store($token);
                    } else {
                        // Resiliente com IoP SDK oficial e injeção de dependências
                        $httpClient = new \DomainSystem\Plugins\domain_drop\Services\OAuth\IopSdkHttpClient(
                            appKey: $appKey,
                            appSecret: $appSecret,
                            gatewayUrl: (string)($config['gateway_url'] ?? 'https://api-sg.aliexpress.com/rest')
                        );
                        $tokenRepo = new \DomainSystem\Plugins\domain_drop\Services\OAuth\ConfigOAuthTokenRepository($this->basePathRoot);
                        $service = new \DomainSystem\Plugins\domain_drop\Services\OAuth\TokenExchangeService($httpClient, $tokenRepo);
                        $token = $service->exchangeCode($code);
                    }

                    $account = $token->account;
                    $expiresInDays = max(1, (int)round($token->expiresIn / 86400));
                    $isSuccess = true;
                } catch (Throwable $e) {
                    $errorMessage = 'Falha ao trocar o código OAuth2 pelo Access Token: ' . $e->getMessage();
                }
            }
        }

        // Auditoria em arquivo de log
        try {
            $logDir = dirname($this->configFile, 3) . '/storage/logs';
            if (!is_dir($logDir)) {
                @mkdir($logDir, 0755, true);
            }
            $logLine = sprintf(
                "[%s] IP: %s | Code: %s | State: %s | Status: %s | Msg: %s\n",
                date('Y-m-d H:i:s'),
                (string)($request->server['REMOTE_ADDR'] ?? 'unknown'),
                $code !== '' ? (substr($code, 0, 10) . '...') : 'empty',
                $state,
                $isSuccess ? 'SUCCESS' : 'ERROR',
                $errorMessage ?? 'Access token exchanged and saved successfully'
            );
            @file_put_contents($logDir . '/aliexpress_oauth.log', $logLine, FILE_APPEND);
        } catch (Throwable $e) {
        }

        if ($isSuccess) {
            $this->session->setFlash('success', '✔️ Conta AliExpress autorizada via OAuth2! Access Token salvo com sucesso.');
        } else {
            $this->session->setFlash('error', $errorMessage ?: 'Erro desconhecido na autorização OAuth2.');
        }

        if ($isLoggedIn) {
            return Response::redirect($baseUrl . '/admin/dropship/settings');
        }

        // Se a sessão interativa não estiver aberta no contexto cross-site, renderiza a tela visual informativa
        ob_start();
        $success = $isSuccess;
        $error = $errorMessage;
        $codeSnippet = $code !== '' ? (substr($code, 0, 12) . '...') : null;
        include dirname(__DIR__) . '/views/admin/oauth_status.php';
        $content = ob_get_clean();

        return new ViewResponse($content ?: '', wrapLayout: false);
    }

    private function resolveOAuthCallbackUrl(string $baseUrl): string
    {
        $config = $this->loadConfig();
        $configuredUri = trim((string)($config['oauth_redirect_uri'] ?? ''));
        if ($configuredUri !== '') {
            return $configuredUri;
        }

        if (str_starts_with($baseUrl, 'http://') || str_starts_with($baseUrl, 'https://')) {
            return rtrim($baseUrl, '/') . '/admin/dropship/callback';
        }
        $isHttps = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off')
            || strtolower((string)($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '')) === 'https'
            || (int)($_SERVER['SERVER_PORT'] ?? 80) === 443;
        $scheme = $isHttps ? 'https' : 'http';
        $rawHost = (string)($_SERVER['HTTP_HOST'] ?? ($_SERVER['SERVER_NAME'] ?? 'localhost'));
        $host = preg_match('/^[a-zA-Z0-9.-]+(?::\d{1,5})?$/', $rawHost) ? $rawHost : 'localhost';
        return $scheme . '://' . $host . $baseUrl . '/admin/dropship/callback';
    }

    public function orders(Request $request): ResponseInterface
    {
        $baseUrl = defined('BASE_URL') ? rtrim(BASE_URL, '/') : '';
        $csrfToken = (string)$this->session->getCsrfToken();
        $status = (string)$request->input('status', '');
        $search = (string)$request->input('q', '');

        $filters = [];
        if ($status !== '') {
            $filters['status'] = $status;
        }
        if ($search !== '') {
            $filters['search'] = $search;
        }

        $orders = $this->orderRepo !== null ? $this->orderRepo->list($filters, 50, 0) : [];
        $registeredCustomers = $this->customerRepo !== null ? $this->customerRepo->listAll(200, 0) : [];
        $customersByEmail = [];
        foreach ($registeredCustomers as $cust) {
            $em = strtolower(trim((string)($cust['email'] ?? '')));
            if ($em !== '') {
                $customersByEmail[$em] = $cust;
            }
        }

        $orderRefs = array_values(array_filter(array_map(static fn (array $o): string => (string)($o['order_ref'] ?? ''), $orders)));
        $disputesByOrder = $this->disputeRepo !== null ? $this->disputeRepo->mapByOrderRefs($orderRefs) : [];
        $slaCalc = $this->slaService ?? new OrderSlaProgressService();

        foreach ($orders as &$ord) {
            $ref = (string)($ord['order_ref'] ?? '');
            $em = strtolower(trim((string)($ord['customer_email'] ?? '')));
            $ordDisputes = $disputesByOrder[$ref] ?? [];
            $ord['disputes'] = $ordDisputes;
            $ord['is_registered_customer'] = isset($customersByEmail[$em]);
            $ord['sla'] = $slaCalc->calculate($ord, $ordDisputes);
        }
        unset($ord);

        $flash = $this->session->getFlash();
        $flashMsg = $flash['msg'] ?? null;
        $flashType = $flash['type'] ?? null;

        ob_start();
        include dirname(__DIR__) . '/views/admin/orders.php';
        $content = ob_get_clean();

        return new ViewResponse($content ?: '');
    }

    public function updateFulfillment(Request $request, string $id): ResponseInterface
    {
        $baseUrl = defined('BASE_URL') ? rtrim(BASE_URL, '/') : '';

        if (!$this->verifyCsrf($request)) {
            $this->session->setFlash('error', 'Token de segurança expirado.');
            return Response::redirect($baseUrl . '/admin/dropship/orders');
        }

        $orderRef = (string)$request->input('order_ref', '');
        $status = (string)$request->input('status', 'paid');
        $aeOrderId = trim((string)$request->input('aliexpress_order_id', ''));
        $tracking = trim((string)$request->input('tracking_code', ''));
        $sellerOrigin = strtoupper(trim((string)$request->input('seller_origin', '')));
        $expectedDays = (int)$request->input('expected_delivery_days', 0);
        $sellerEmail = trim((string)$request->input('seller_email', ''));

        if ($this->orderRepo !== null && $orderRef !== '') {
            $existingOrder = $this->orderRepo->findByOrderRef($orderRef);
            $this->orderRepo->updateFulfillment(
                $orderRef,
                $status,
                $aeOrderId !== '' ? $aeOrderId : null,
                $tracking !== '' ? $tracking : null
            );

            if ($sellerOrigin !== '') {
                $days = $expectedDays > 0 ? $expectedDays : ($sellerOrigin === 'CN' ? 25 : 7);
                $this->orderRepo->updateSellerAndSla(
                    $orderRef,
                    $sellerOrigin,
                    $days,
                    null,
                    $sellerEmail !== '' ? $sellerEmail : null
                );
            }

            // Notifica o cliente por e-mail automaticamente caso haja novo código de rastreio
            if ($this->notificationService !== null && $tracking !== '' && is_array($existingOrder)) {
                $prevTracking = trim((string)($existingOrder['tracking_code'] ?? ''));
                if (strcasecmp($prevTracking, $tracking) !== 0) {
                    $existingOrder['order_ref'] = $orderRef;
                    $this->notificationService->notifyOrderShipped($existingOrder, $tracking);
                }
            }

            $this->session->setFlash('success', 'Status de envio do pedido atualizado com sucesso!');
        }

        return Response::redirect($baseUrl . '/admin/dropship/orders');
    }

    /**
     * Consulta o SDK oficial do AliExpress para verificar se o item chegou ao destino.
     */
    public function checkOrderSdk(Request $request, string $id): ResponseInterface
    {
        $baseUrl = defined('BASE_URL') ? rtrim(BASE_URL, '/') : '';
        $isAjax = $this->isAjaxOrJson($request);

        if (!$this->verifyCsrf($request)) {
            if ($isAjax) {
                return new JsonResponse(['success' => false, 'message' => 'Token de segurança expirado.'], 403);
            }
            $this->session->setFlash('error', 'Token de segurança expirado.');
            return Response::redirect($baseUrl . '/admin/dropship/orders');
        }

        $orderRef = trim((string)$request->input('order_ref', ''));
        $order = ($this->orderRepo !== null && $orderRef !== '') ? $this->orderRepo->findByOrderRef($orderRef) : null;
        if ($order === null) {
            if ($isAjax) {
                return new JsonResponse(['success' => false, 'message' => 'Pedido não encontrado.'], 404);
            }
            $this->session->setFlash('error', 'Pedido não encontrado.');
            return Response::redirect($baseUrl . '/admin/dropship/orders');
        }

        $trackingCode = trim((string)($order['tracking_code'] ?? ''));
        $aeOrderId = trim((string)($order['aliexpress_order_id'] ?? ''));

        if ($trackingCode === '' || $this->apiClient === null) {
            $msg = 'Informe o código de rastreio do pedido antes de consultar o SDK logístico.';
            if ($isAjax) {
                return new JsonResponse(['success' => false, 'message' => $msg], 422);
            }
            $this->session->setFlash('error', $msg);
            return Response::redirect($baseUrl . '/admin/dropship/orders');
        }

        try {
            $sdkRes = $this->apiClient->queryTrackingInfo(
                logisticsNo: $trackingCode,
                origin: 'ESCROW',
                outRef: $aeOrderId,
                serviceName: preg_match('/BR$/i', $trackingCode) ? 'CORREIOS' : 'CAINIAO',
                toArea: 'BR'
            );

            $slaCalc = $this->slaService ?? new OrderSlaProgressService();
            $parsed = $slaCalc->parseSdkTracking($sdkRes);
            $summaryJson = json_encode($sdkRes, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) ?: '{}';

            if ($parsed['delivered']) {
                $this->orderRepo->updateSdkTracking(
                    $orderRef,
                    date('Y-m-d H:i:s'),
                    $summaryJson,
                    'delivered'
                );
                $msg = 'SDK AliExpress confirmou: item entregue no local! Pedido atualizado para "Tudo Ok".';
            } else {
                $this->orderRepo->updateSdkTracking($orderRef, null, $summaryJson, null);
                $msg = 'SDK consultado: encomenda ainda em trânsito (' . ($parsed['last_event'] !== '' ? $parsed['last_event'] : $parsed['status_code']) . ').';
            }

            if ($isAjax) {
                return new JsonResponse(['success' => true, 'delivered' => $parsed['delivered'], 'message' => $msg, 'tracking' => $parsed]);
            }
            $this->session->setFlash('success', $msg);
        } catch (Throwable $e) {
            $msg = 'Falha ao consultar SDK logístico: ' . $e->getMessage();
            if ($isAjax) {
                return new JsonResponse(['success' => false, 'message' => $msg], 500);
            }
            $this->session->setFlash('error', $msg);
        }

        return Response::redirect($baseUrl . '/admin/dropship/orders');
    }

    /**
     * Botão único de intermediação com o fornecedor (PT-BR se Brasil, traduzido para Chinês se China).
     */
    public function mediateDispute(Request $request, string $id): ResponseInterface
    {
        $baseUrl = defined('BASE_URL') ? rtrim(BASE_URL, '/') : '';
        $isAjax = $this->isAjaxOrJson($request);

        if (!$this->verifyCsrf($request)) {
            if ($isAjax) {
                return new JsonResponse(['success' => false, 'message' => 'Token de segurança expirado.'], 403);
            }
            $this->session->setFlash('error', 'Token de segurança expirado.');
            return Response::redirect($baseUrl . '/admin/dropship/orders');
        }

        $orderRef = trim((string)$request->input('order_ref', ''));
        $disputeId = (int)$request->input('dispute_id', 0);

        $order = ($this->orderRepo !== null && $orderRef !== '') ? $this->orderRepo->findByOrderRef($orderRef) : null;
        if ($order === null) {
            if ($isAjax) {
                return new JsonResponse(['success' => false, 'message' => 'Pedido não encontrado.'], 404);
            }
            $this->session->setFlash('error', 'Pedido não encontrado.');
            return Response::redirect($baseUrl . '/admin/dropship/orders');
        }

        $dispute = null;
        if ($this->disputeRepo !== null) {
            $dispute = $disputeId > 0 ? $this->disputeRepo->findById($disputeId) : null;
            if ($dispute === null) {
                $list = $this->disputeRepo->findByOrderRef($orderRef);
                $dispute = $list[0] ?? null;
            }
        }

        if ($dispute === null || $this->mediationService === null) {
            $msg = 'Nenhuma reclamação aberta encontrada para intermediar.';
            if ($isAjax) {
                return new JsonResponse(['success' => false, 'message' => $msg], 404);
            }
            $this->session->setFlash('error', $msg);
            return Response::redirect($baseUrl . '/admin/dropship/orders');
        }

        $overrideOrigin = strtoupper(trim((string)$request->input('seller_origin', '')));
        if (in_array($overrideOrigin, ['BR', 'CN'], true)) {
            $dispute['seller_origin'] = $overrideOrigin;
        }

        $result = $this->mediationService->sendMediation($order, $dispute, $baseUrl);
        $langLabel = ($result['seller_language'] ?? '') === 'zh-CN'
            ? 'Chinês Simplificado (zh-CN)'
            : 'Português (pt-BR)';

        $msg = "Intermediação enviada ao fornecedor em {$langLabel}!";
        if ($isAjax) {
            return new JsonResponse([
                'success'            => true,
                'message'            => $msg,
                'seller_language'    => $result['seller_language'] ?? 'zh-CN',
                'channel'            => $result['channel'] ?? 'aliexpress_mediation_log',
                'translated_message' => $result['translated_message'] ?? '',
            ]);
        }

        $this->session->setFlash('success', $msg);
        return Response::redirect($baseUrl . '/admin/dropship/orders');
    }

    public function syncImages(Request $request, string $id): ResponseInterface
    {
        $baseUrl = defined('BASE_URL') ? rtrim(BASE_URL, '/') : '';
        $isAjax = $this->isAjaxOrJson($request);

        if (!$this->verifyCsrf($request)) {
            if ($isAjax) {
                return new JsonResponse(['success' => false, 'message' => 'Token de segurança expirado.'], 403);
            }
            $this->session->setFlash('error', 'Token de segurança expirado.');
            return Response::redirect($baseUrl . '/admin/dropship');
        }

        if ($this->mediaSync === null) {
            if ($isAjax) {
                return new JsonResponse(['success' => false, 'message' => 'Serviço de sincronização de mídia indisponível.'], 503);
            }
            $this->session->setFlash('error', 'Serviço de sincronização de mídia indisponível.');
            return Response::redirect($baseUrl . '/admin/dropship');
        }

        try {
            $updated = $this->mediaSync->syncProductMedia((int)$id);
            $images = $this->filterImageUrls(array_merge([$updated->mainImageUrl], $updated->images));
            $mainImageUrl = $updated->mainImageUrl ?: ($images[0] ?? '');
            $imgCount = count($images);
            $msg = "🔄 Produto '{$updated->title}' sincronizado com sucesso! {$imgCount} foto(s) em alta resolução carregada(s).";

            if ($isAjax) {
                $rate = $this->currencyConverter->getExchangeRate('USD', 'BRL');
                if ($rate <= 0) {
                    $rate = 5.50;
                }
                return new JsonResponse([
                    'success'        => true,
                    'message'        => $msg,
                    'title'          => $updated->title,
                    'main_image_url' => $mainImageUrl,
                    'images'         => $images,
                    'count'          => $imgCount,
                    'sale_formatted' => 'R$ ' . number_format($updated->salePriceBrl, 2, ',', '.'),
                    'cost_formatted' => 'R$ ' . number_format($updated->costPriceUsd * $rate, 2, ',', '.'),
                    'cost_price_usd' => $updated->costPriceUsd,
                ]);
            }

            $this->session->setFlash('success', $msg);
        } catch (Throwable $e) {
            $prodId = (int)$id;
            $autoPurge = filter_var($request->input('auto_purge', false), FILTER_VALIDATE_BOOLEAN);
            $isNotFoundOnSupplier = str_starts_with($e->getMessage(), 'PAGINA_NAO_ENCONTRADA:')
                || stripos($e->getMessage(), 'Página não encontrada') !== false
                || stripos($e->getMessage(), 'não foi encontrado') !== false
                || stripos($e->getMessage(), 'não está mais disponível') !== false
                || stripos($e->getMessage(), 'Item no longer available') !== false;

            if (($isNotFoundOnSupplier || $autoPurge) && $prodId > 0) {
                $this->catalogRepo->delete($prodId);
                $delMsg = "🗑️ Produto #{$prodId} excluído automaticamente: fornecedor sem estoque, link desativado ou página não encontrada no AliExpress.";
                if ($isAjax) {
                    return new JsonResponse([
                        'success'    => false,
                        'deleted'    => true,
                        'reason'     => 'not_found',
                        'product_id' => $prodId,
                        'message'    => $delMsg,
                    ], 200);
                }
                $this->session->setFlash('success', $delMsg);
                return Response::redirect($baseUrl . '/admin/dropship');
            }

            if (str_starts_with($e->getMessage(), 'SDK_NAO_AUTORIZADO:')) {
                $authMsg = "🔑 Access Token OAuth do AliExpress não autorizado em Configurações & API: o produto #{$prodId} foi preservado publicado sem recorrer a scraping.";
                if ($isAjax) {
                    return new JsonResponse([
                        'success'         => false,
                        'temporary_block' => true,
                        'product_id'      => $prodId,
                        'message'         => $authMsg,
                    ], 200);
                }
                $this->session->setFlash('warning', $authMsg);
                return Response::redirect($baseUrl . '/admin/dropship');
            }

            if (str_starts_with($e->getMessage(), 'BLOQUEIO_TEMPORARIO_FORNECEDOR:')) {
                $tempMsg = "⏳ Verificação anti-robô temporária (captcha) do AliExpress: o produto #{$prodId} foi preservado publicado sem alterações.";
                if ($isAjax) {
                    return new JsonResponse([
                        'success'         => false,
                        'temporary_block' => true,
                        'product_id'      => $prodId,
                        'message'         => $tempMsg,
                    ], 200);
                }
                $this->session->setFlash('warning', $tempMsg);
                return Response::redirect($baseUrl . '/admin/dropship');
            }

            // Regra de Integridade: Se houve erro de conteúdo sem fotos, move para Rascunho
            if ($prodId > 0) {
                $this->catalogRepo->updateStatus($prodId, 'draft');
            }

            $errMsg = "⚠️ Fornecedor não encontrado ou sem fotos reais: {$e->getMessage()}. O produto foi despublicado da loja e movido para Rascunho / Fila de Exclusão.";
            if ($isAjax) {
                return new JsonResponse([
                    'success'      => false,
                    'message'      => $errMsg,
                    'unregistered' => true,
                    'product_id'   => $prodId,
                    'new_status'   => 'draft'
                ], 422);
            }
            $this->session->setFlash('warning', $errMsg);
        }

        return Response::redirect($baseUrl . '/admin/dropship');
    }

    public function updateImages(Request $request, string $id): ResponseInterface
    {
        $baseUrl = defined('BASE_URL') ? rtrim(BASE_URL, '/') : '';
        $isAjax = $this->isAjaxOrJson($request);

        if (!$this->verifyCsrf($request)) {
            if ($isAjax) {
                return new JsonResponse(['success' => false, 'message' => 'Token de segurança expirado.'], 403);
            }
            $this->session->setFlash('error', 'Token de segurança expirado.');
            return Response::redirect($baseUrl . '/admin/dropship');
        }

        $product = $this->catalogRepo->findById((int)$id);
        if ($product === null) {
            if ($isAjax) {
                return new JsonResponse(['success' => false, 'message' => 'Produto não encontrado.'], 404);
            }
            $this->session->setFlash('error', 'Produto não encontrado.');
            return Response::redirect($baseUrl . '/admin/dropship');
        }

        $rawImages = $request->input('images_json');
        $parsedImages = [];
        if (is_string($rawImages) && trim($rawImages) !== '') {
            $decoded = json_decode($rawImages, true);
            if (is_array($decoded)) {
                $parsedImages = $decoded;
            }
        } elseif (is_array($request->input('images'))) {
            $parsedImages = $request->input('images');
        }

        $mainImageInput = trim((string)$request->input('main_image_url', ''));
        $validImages = $this->filterImageUrls($parsedImages);
        $validMain = $this->filterImageUrls([$mainImageInput])[0] ?? ($validImages[0] ?? '');

        if ($validMain === '' && empty($validImages)) {
            $errMsg = 'Informe pelo menos 1 URL de imagem HTTP/HTTPS válida.';
            if ($isAjax) {
                return new JsonResponse(['success' => false, 'message' => $errMsg], 422);
            }
            $this->session->setFlash('error', $errMsg);
            return Response::redirect($baseUrl . '/admin/dropship');
        }

        // Garante que a imagem principal esteja na lista (em primeiro lugar)
        $orderedImages = $this->filterImageUrls(array_merge([$validMain], $validImages));

        $attributes = is_array($product->attributes) ? $product->attributes : [];
        if ($request->has('video_url')) {
            $videoInput = trim((string)$request->input('video_url', ''));
            if ($videoInput === '' || filter_var($videoInput, FILTER_VALIDATE_URL) || str_starts_with($videoInput, '//')) {
                if (str_starts_with($videoInput, '//')) {
                    $videoInput = 'https:' . $videoInput;
                }
                $attributes['video_url'] = $videoInput;
                $attributes['product_video_url'] = $videoInput;
            }
        }

        $updatedDto = new DropshipProductDto(
            aliexpressId: $product->aliexpressId,
            title: $product->title,
            slug: $product->slug,
            costPriceUsd: $product->costPriceUsd,
            salePriceBrl: $product->salePriceBrl,
            mainImageUrl: $validMain,
            images: $orderedImages,
            category: $product->category,
            description: $product->description,
            rating: $product->rating,
            ordersCount: $product->ordersCount,
            attributes: $attributes,
            status: $product->status,
            id: $product->id
        );

        $this->catalogRepo->save($updatedDto);

        $count = count($orderedImages);
        $savedVideoUrl = (string)($attributes['video_url'] ?? '');
        $msg = "🖼️ Galeria de '{$product->title}' atualizada! {$count} foto(s) salva(s).";

        if ($isAjax) {
            return new JsonResponse([
                'success'        => true,
                'message'        => $msg,
                'main_image_url' => $validMain,
                'images'         => $orderedImages,
                'video_url'      => $savedVideoUrl,
                'count'          => $count,
            ]);
        }

        $this->session->setFlash('success', $msg);
        return Response::redirect($baseUrl . '/admin/dropship');
    }

    /**
     * @param array<int, mixed> $urls
     * @return array<int, string>
     */
    private function filterImageUrls(array $urls): array
    {
        $clean = [];
        foreach ($urls as $raw) {
            if (!is_string($raw)) {
                continue;
            }
            $url = trim($raw);
            if ($url === '' || !filter_var($url, FILTER_VALIDATE_URL)) {
                continue;
            }
            $scheme = strtolower((string)parse_url($url, PHP_URL_SCHEME));
            if ($scheme !== 'http' && $scheme !== 'https') {
                continue;
            }
            if (!in_array($url, $clean, true)) {
                $clean[] = $url;
            }
        }
        return $clean;
    }

    public function syncQueue(Request $request): ResponseInterface
    {
        $products = $this->catalogRepo->list([], 500, 0);
        $items = [];
        $totalSingleOrEmpty = 0;
        $totalMulti = 0;

        foreach ($products as $p) {
            if ($p->id === null) {
                continue;
            }
            $images = !empty($p->images) ? array_values(array_filter($p->images)) : [];
            $imgCount = count($images);
            $hasMultiple = $imgCount > 1;

            if ($hasMultiple) {
                $totalMulti++;
            } else {
                $totalSingleOrEmpty++;
            }

            $items[] = [
                'id'            => (int)$p->id,
                'title'         => $p->title,
                'aliexpress_id' => $p->aliexpressId,
                'images_count'  => $imgCount,
                'needs_sync'    => !$hasMultiple,
                'category'      => $p->category,
                'main_image'    => $p->mainImageUrl,
            ];
        }

        return new JsonResponse([
            'success'               => true,
            'total'                 => count($items),
            'single_or_empty_count' => $totalSingleOrEmpty,
            'multi_count'           => $totalMulti,
            'items'                 => $items,
        ]);
    }

    public function syncAllImages(Request $request): ResponseInterface
    {
        $baseUrl = defined('BASE_URL') ? rtrim(BASE_URL, '/') : '';

        if (!$this->verifyCsrf($request)) {
            $this->session->setFlash('error', 'Token de segurança expirado.');
            return Response::redirect($baseUrl . '/admin/dropship');
        }

        if ($this->mediaSync === null) {
            $this->session->setFlash('error', 'Serviço de sincronização de mídia indisponível.');
            return Response::redirect($baseUrl . '/admin/dropship');
        }

        try {
            $res = $this->mediaSync->syncAllCatalogMedia(true);
            $skipped = (int)($res['skipped_already_multiple'] ?? 0);
            $msg = "🔄 Varredura inteligente concluída: {$res['synced']} produto(s) sincronizado(s) com a galeria oficial.";
            if ($skipped > 0) {
                $msg .= " ({$skipped} produtos já possuíam galeria completa com mais de 1 foto e foram preservados).";
            }
            $this->session->setFlash('success', $msg);
        } catch (Throwable $e) {
            $this->session->setFlash('error', "Falha na sincronização em lote: " . $e->getMessage());
        }

        return Response::redirect($baseUrl . '/admin/dropship');
    }

    public function delete(Request $request, string $id): ResponseInterface
    {
        $baseUrl = defined('BASE_URL') ? rtrim(BASE_URL, '/') : '';
        $isAjax = $this->isAjaxOrJson($request);

        if (!$this->verifyCsrf($request)) {
            if ($isAjax) {
                return new JsonResponse(['success' => false, 'message' => 'Token de segurança expirado.'], 403);
            }
            $this->session->setFlash('error', 'Token de segurança expirado.');
            return Response::redirect($baseUrl . '/admin/dropship');
        }

        $prodId = (int)$id;
        if ($prodId > 0) {
            $this->catalogRepo->delete($prodId);
        }

        if ($isAjax) {
            return new JsonResponse([
                'success' => true,
                'deleted' => true,
                'id'      => $prodId,
                'message' => "Produto #{$prodId} removido do catálogo com sucesso."
            ]);
        }

        $this->session->setFlash('success', 'Produto removido do catálogo.');

        return Response::redirect($baseUrl . '/admin/dropship');
    }

    public function purgeInvalidProducts(Request $request): ResponseInterface
    {
        $baseUrl = defined('BASE_URL') ? rtrim(BASE_URL, '/') : '';
        $isAjax = $this->isAjaxOrJson($request);

        if (!$this->verifyCsrf($request)) {
            if ($isAjax) {
                return new JsonResponse(['success' => false, 'message' => 'Token de segurança expirado.'], 403);
            }
            $this->session->setFlash('error', 'Token de segurança expirado.');
            return Response::redirect($baseUrl . '/admin/dropship');
        }

        $jsonBody = $request->json();
        $rawIds = (is_array($jsonBody) && array_key_exists('ids', $jsonBody))
            ? $jsonBody['ids']
            : $request->input('ids', []);
        if (is_string($rawIds)) {
            $rawIds = json_decode($rawIds, true) ?: [];
        }

        $deletedCount = 0;
        if (is_array($rawIds)) {
            foreach ($rawIds as $id) {
                $pId = (int)$id;
                if ($pId > 0) {
                    $this->catalogRepo->delete($pId);
                    $deletedCount++;
                }
            }
        }

        $msg = "🗑️ {$deletedCount} produto(s) inválido(s) / com página não encontrada foram removidos com sucesso.";
        if ($isAjax) {
            return new JsonResponse([
                'success'       => true,
                'deleted_count' => $deletedCount,
                'message'       => $msg
            ]);
        }

        $this->session->setFlash('success', $msg);
        return Response::redirect($baseUrl . '/admin/dropship');
    }

    public function updatePrice(Request $request, string $id): ResponseInterface
    {
        $baseUrl = defined('BASE_URL') ? rtrim(BASE_URL, '/') : '';

        if (!$this->verifyCsrf($request)) {
            if ($this->isAjaxOrJson($request)) {
                return new JsonResponse(['success' => false, 'message' => 'Token de segurança expirado.'], 403);
            }
            $this->session->setFlash('error', 'Token de segurança expirado.');
            return Response::redirect($baseUrl . '/admin/dropship');
        }

        $productId = (int)$id;
        $product = $this->catalogRepo->findById($productId);
        if ($product === null) {
            if ($this->isAjaxOrJson($request)) {
                return new JsonResponse(['success' => false, 'message' => 'Produto não encontrado.'], 404);
            }
            $this->session->setFlash('error', 'Produto não encontrado.');
            return Response::redirect($baseUrl . '/admin/dropship');
        }

        $rate = $this->currencyConverter->getExchangeRate('USD', 'BRL');
        if ($rate <= 0) {
            $rate = 5.50;
        }

        // Preço de venda em BRL
        $salePriceBrl = max(0.01, $this->parseCurrency($request->input('sale_price_brl')));

        // Custo pode ser informado em BRL ou USD
        $costPriceUsd = null;
        if ($request->input('cost_price_brl') !== null && $request->input('cost_price_brl') !== '') {
            $costBrl = max(0.0, $this->parseCurrency($request->input('cost_price_brl')));
            $costPriceUsd = round($costBrl / $rate, 2);
        } elseif ($request->input('cost_price_usd') !== null && $request->input('cost_price_usd') !== '') {
            $costPriceUsd = max(0.0, $this->parseCurrency($request->input('cost_price_usd')));
        }

        $this->catalogRepo->updatePrice($productId, $salePriceBrl, $costPriceUsd);

        $finalCostUsd = $costPriceUsd ?? $product->costPriceUsd;
        $finalCostBrl = $finalCostUsd * $rate;
        $profitBrl = $salePriceBrl - $finalCostBrl;
        $marginPercent = ($salePriceBrl > 0) ? round(($profitBrl / $salePriceBrl) * 100, 1) : 0;

        $msg = "💰 Preço de '{$product->title}' atualizado com sucesso! Venda: R$ " . number_format($salePriceBrl, 2, ',', '.') . " (Margem: {$marginPercent}% / R$ " . number_format($profitBrl, 2, ',', '.') . ")";

        if ($this->isAjaxOrJson($request)) {
            return new JsonResponse([
                'success'        => true,
                'message'        => $msg,
                'sale_price_brl' => $salePriceBrl,
                'sale_formatted' => 'R$ ' . number_format($salePriceBrl, 2, ',', '.'),
                'cost_price_usd' => $finalCostUsd,
                'cost_price_brl' => round($finalCostBrl, 2),
                'cost_formatted' => 'R$ ' . number_format($finalCostBrl, 2, ',', '.'),
                'profit_brl'     => round($profitBrl, 2),
                'margin_percent' => $marginPercent,
            ]);
        }

        $this->session->setFlash('success', $msg);
        return Response::redirect($baseUrl . '/admin/dropship');
    }

    public function updateCategory(Request $request, string $id): ResponseInterface
    {
        $baseUrl = defined('BASE_URL') ? rtrim(BASE_URL, '/') : '';

        if (!$this->verifyCsrf($request)) {
            if ($this->isAjaxOrJson($request)) {
                return new JsonResponse(['success' => false, 'message' => 'Token de segurança expirado.'], 403);
            }
            $this->session->setFlash('error', 'Token de segurança expirado.');
            return Response::redirect($baseUrl . '/admin/dropship');
        }

        $productId = (int)$id;
        $product = $this->catalogRepo->findById($productId);
        if ($product === null) {
            if ($this->isAjaxOrJson($request)) {
                return new JsonResponse(['success' => false, 'message' => 'Produto não encontrado.'], 404);
            }
            $this->session->setFlash('error', 'Produto não encontrado.');
            return Response::redirect($baseUrl . '/admin/dropship');
        }

        $newCategory = trim((string)$request->input('category', ''));
        if ($newCategory === '') {
            if ($this->isAjaxOrJson($request)) {
                return new JsonResponse(['success' => false, 'message' => 'Categoria inválida informada.'], 400);
            }
            $this->session->setFlash('error', 'Categoria inválida informada.');
            return Response::redirect($baseUrl . '/admin/dropship');
        }

        $commercialCat = \DomainSystem\Plugins\domain_drop\Services\ProductMiningService::toCommercialCategory($newCategory);
        $this->catalogRepo->updateCategory($productId, $commercialCat);

        $msg = "🏷️ Categoria de '{$product->title}' alterada para '{$commercialCat}' com sucesso!";

        if ($this->isAjaxOrJson($request)) {
            return new JsonResponse([
                'success'  => true,
                'message'  => $msg,
                'category' => $commercialCat,
            ]);
        }

        $this->session->setFlash('success', $msg);
        return Response::redirect($baseUrl . '/admin/dropship');
    }

    public function updateOrigin(Request $request, string $id): ResponseInterface
    {
        $baseUrl = defined('BASE_URL') ? rtrim(BASE_URL, '/') : '';

        if (!$this->verifyCsrf($request)) {
            if ($this->isAjaxOrJson($request)) {
                return new JsonResponse(['success' => false, 'message' => 'Token de segurança expirado.'], 403);
            }
            $this->session->setFlash('error', 'Token de segurança expirado.');
            return Response::redirect($baseUrl . '/admin/dropship');
        }

        $productId = (int)$id;
        $product = $this->catalogRepo->findById($productId);
        if ($product === null) {
            if ($this->isAjaxOrJson($request)) {
                return new JsonResponse(['success' => false, 'message' => 'Produto não encontrado.'], 404);
            }
            $this->session->setFlash('error', 'Produto não encontrado.');
            return Response::redirect($baseUrl . '/admin/dropship');
        }

        $origin = strtoupper(trim((string)$request->input('origin', 'GLOBAL')));
        if (!in_array($origin, ['BR', 'CN', 'GLOBAL'], true)) {
            $origin = 'GLOBAL';
        }

        $this->catalogRepo->updateOrigin($productId, $origin);

        $label = match ($origin) {
            'BR' => 'Estoque no Brasil (Nacional) 🇧🇷',
            'CN' => 'Importação Oficial AliExpress (China) 🇨🇳',
            default => 'Origem Internacional Certificada 🌐',
        };

        $badgeFlag = match ($origin) {
            'BR' => '<span>🇧🇷</span> BR',
            'CN' => '<span>🇨🇳</span> CN',
            default => '<span>🌐</span> GLOBAL',
        };

        $badgeBg = match ($origin) {
            'BR' => 'rgba(16, 185, 129, 0.9)',
            'CN' => 'rgba(59, 130, 246, 0.9)',
            default => 'rgba(100, 116, 139, 0.9)',
        };

        $msg = "📍 Procedência de '{$product->title}' alterada para {$label} com sucesso!";

        if ($this->isAjaxOrJson($request)) {
            return new JsonResponse([
                'success'    => true,
                'message'    => $msg,
                'origin'     => $origin,
                'label'      => $label,
                'badge_flag' => $badgeFlag,
                'badge_bg'   => $badgeBg,
            ]);
        }

        $this->session->setFlash('success', $msg);
        return Response::redirect($baseUrl . '/admin/dropship');
    }

    public function updateProductConfig(Request $request, string $id): ResponseInterface
    {
        $baseUrl = defined('BASE_URL') ? rtrim(BASE_URL, '/') : '';

        if (!$this->verifyCsrf($request)) {
            if ($this->isAjaxOrJson($request)) {
                return new JsonResponse(['success' => false, 'message' => 'Token de segurança expirado.'], 403);
            }
            $this->session->setFlash('error', 'Token de segurança expirado.');
            return Response::redirect($baseUrl . '/admin/dropship');
        }

        $productId = (int)$id;
        $product = $this->catalogRepo->findById($productId);
        if ($product === null) {
            if ($this->isAjaxOrJson($request)) {
                return new JsonResponse(['success' => false, 'message' => 'Produto não encontrado.'], 404);
            }
            $this->session->setFlash('error', 'Produto não encontrado.');
            return Response::redirect($baseUrl . '/admin/dropship');
        }

        // 1. Processamento e higienização de Tamanhos
        $rawSizes = $request->input('sizes');
        $sizesList = [];
        if (is_array($rawSizes)) {
            $sizesList = $rawSizes;
        } elseif (is_string($rawSizes)) {
            $sizesList = explode(',', $rawSizes);
        }
        $cleanSizes = [];
        foreach ($sizesList as $s) {
            $s = trim((string)$s);
            if ($s !== '') {
                if (preg_match('/^[a-z]{1,4}$/i', $s)) {
                    $s = strtoupper($s);
                }
                if (!in_array($s, $cleanSizes, true)) {
                    $cleanSizes[] = $s;
                }
            }
        }

        // 2. Processamento e higienização de Cores
        $rawColors = $request->input('colors');
        $colorsList = [];
        if (is_array($rawColors)) {
            $colorsList = $rawColors;
        } elseif (is_string($rawColors)) {
            $colorsList = explode(',', $rawColors);
        }
        $cleanColors = [];
        foreach ($colorsList as $c) {
            $c = trim((string)$c);
            if ($c !== '') {
                $c = mb_convert_case($c, MB_CASE_TITLE, 'UTF-8');
                if (!in_array($c, $cleanColors, true)) {
                    $cleanColors[] = $c;
                }
            }
        }

        // 3. Processamento de Política de Frete
        $rawFreteGratis = $request->input('frete_gratis');
        $freteGratis = ($rawFreteGratis === true || $rawFreteGratis === 1 || $rawFreteGratis === '1' || $rawFreteGratis === 'true');
        $freteTipo = trim((string)$request->input('frete_tipo', 'gratis'));
        if (!in_array($freteTipo, ['gratis', 'pago', 'expresso'], true)) {
            $freteTipo = $freteGratis ? 'gratis' : 'pago';
        }
        $freteValor = max(0.0, $this->parseCurrency($request->input('frete_valor', 0.0)));
        if ($freteTipo === 'gratis') {
            $freteGratis = true;
            $freteValor = 0.0;
        } elseif ($freteValor <= 0.0) {
            return new JsonResponse(['success' => false, 'message' => 'Informe um valor maior que R$ 0,00 para frete pago/expresso.'], 422);
        }

        // 4. Link oficial do Fornecedor / AliExpress
        $aliexpressUrl = trim((string)$request->input('aliexpress_url', ''));
        if ($aliexpressUrl !== '') {
            $parsedAe = parse_url($aliexpressUrl);
            $aeScheme = strtolower((string)($parsedAe['scheme'] ?? ''));
            if (!filter_var($aliexpressUrl, FILTER_VALIDATE_URL) || !in_array($aeScheme, ['http', 'https'], true)) {
                return new JsonResponse(['success' => false, 'message' => 'URL do fornecedor inválida. Utilize http:// ou https://.'], 422);
            }
        }

        // 5. Atualização de atributos estruturados
        $attributes = $product->attributes;

        if (!empty($cleanSizes)) {
            $attributes['tamanhos_disponiveis'] = $cleanSizes;
            if (!isset($attributes['variation_axes']) || !is_array($attributes['variation_axes'])) {
                $attributes['variation_axes'] = [];
            }
            $attributes['variation_axes']['Tamanho'] = $cleanSizes;
        } else {
            unset($attributes['tamanhos_disponiveis']);
            if (isset($attributes['variation_axes']['Tamanho'])) {
                unset($attributes['variation_axes']['Tamanho']);
            }
            if (isset($attributes['variation_axes']['Size'])) {
                unset($attributes['variation_axes']['Size']);
            }
        }

        if (!empty($cleanColors)) {
            $attributes['cores_disponiveis'] = $cleanColors;
            if (!isset($attributes['variation_axes']) || !is_array($attributes['variation_axes'])) {
                $attributes['variation_axes'] = [];
            }
            $attributes['variation_axes']['Cor'] = $cleanColors;
        } else {
            unset($attributes['cores_disponiveis']);
            if (isset($attributes['variation_axes']['Cor'])) {
                unset($attributes['variation_axes']['Cor']);
            }
            if (isset($attributes['variation_axes']['Color'])) {
                unset($attributes['variation_axes']['Color']);
            }
        }

        if (empty($attributes['variation_axes'])) {
            unset($attributes['variation_axes']);
        }

        $attributes['frete_gratis'] = $freteGratis;
        $attributes['frete_tipo'] = $freteTipo;
        $attributes['frete_valor'] = $freteValor;

        if ($aliexpressUrl !== '') {
            $attributes['aliexpress_url'] = $aliexpressUrl;
        }

        // 6. Reconstituição da Matriz SKU (Product Variants Matrix)
        $colorMatrix = !empty($cleanColors) ? $cleanColors : [null];
        $sizeMatrix = !empty($cleanSizes) ? $cleanSizes : [null];

        $existingVariants = $product->getVariants();
        $existingMap = [];
        $usedSkuIds = [];
        foreach ($existingVariants as $ev) {
            $usedSkuIds[] = $ev->skuId;
            $c = $ev->options['Cor'] ?? ($ev->options['cor'] ?? ($ev->options['Color'] ?? ''));
            $s = $ev->options['Tamanho'] ?? ($ev->options['tamanho'] ?? ($ev->options['Size'] ?? ''));
            $key = mb_strtolower(trim((string)$c)) . '|' . mb_strtolower(trim((string)$s));
            $existingMap[$key] = $ev;
        }

        $newVariants = [];
        $counter = 1;
        foreach ($colorMatrix as $cVal) {
            foreach ($sizeMatrix as $sVal) {
                $options = [];
                if ($cVal !== null && $cVal !== '') {
                    $options['Cor'] = $cVal;
                }
                if ($sVal !== null && $sVal !== '') {
                    $options['Tamanho'] = $sVal;
                }
                if (empty($options)) {
                    continue;
                }

                $lookupKey = mb_strtolower(trim((string)$cVal)) . '|' . mb_strtolower(trim((string)$sVal));
                $match = $existingMap[$lookupKey] ?? null;

                if ($match) {
                    $skuId = $match->skuId;
                } else {
                    do {
                        $candidate = 'sku_' . $product->aliexpressId . '_' . $counter++;
                    } while (in_array($candidate, $usedSkuIds, true));
                    $skuId = $candidate;
                }
                $usedSkuIds[] = $skuId;
                $skuAttr = $match ? $match->skuAttr : '';
                $priceBrl = $match ? $match->priceBrl : $product->salePriceBrl;
                $costUsd = $match ? $match->costPriceUsd : $product->costPriceUsd;
                $imgUrl = $match ? $match->imageUrl : $product->mainImageUrl;
                $stock = $match ? $match->stock : 100;
                $ean = $match ? $match->eanCode : '';

                $newVariants[] = [
                    'sku_id'         => $skuId,
                    'sku_attr'       => $skuAttr,
                    'options'        => $options,
                    'price_brl'      => $priceBrl,
                    'cost_price_usd' => $costUsd,
                    'image_url'      => $imgUrl,
                    'stock'          => $stock,
                    'ean_code'       => $ean,
                ];
                $counter++;
            }
        }

        if (!empty($newVariants)) {
            $attributes['variants'] = $newVariants;
        } else {
            unset($attributes['variants']);
        }

        $updatedProduct = new DropshipProductDto(
            aliexpressId: $product->aliexpressId,
            title: $product->title,
            slug: $product->slug,
            costPriceUsd: $product->costPriceUsd,
            salePriceBrl: $product->salePriceBrl,
            mainImageUrl: $product->mainImageUrl,
            images: $product->images,
            category: $product->category,
            description: $product->description,
            rating: $product->rating,
            ordersCount: $product->ordersCount,
            attributes: $attributes,
            status: $product->status,
            id: $product->id
        );

        $this->catalogRepo->save($updatedProduct);

        $msg = "⚙️ Configurações e variações de '{$product->title}' atualizadas com sucesso! " .
               (count($cleanSizes) > 0 ? "Tamanhos: " . implode(', ', $cleanSizes) . ". " : "") .
               (count($cleanColors) > 0 ? "Cores: " . implode(', ', $cleanColors) . ". " : "") .
               "Frete: " . ($freteGratis ? 'Grátis' : 'R$ ' . number_format($freteValor, 2, ',', '.')) . ".";

        if ($this->isAjaxOrJson($request)) {
            return new JsonResponse([
                'success'         => true,
                'message'         => $msg,
                'product_id'      => $productId,
                'sizes'           => $cleanSizes,
                'colors'          => $cleanColors,
                'variants_count'  => count($newVariants),
                'frete_gratis'    => $freteGratis,
                'frete_tipo'      => $freteTipo,
                'frete_valor'     => $freteValor,
                'frete_formatted' => $freteGratis ? 'Frete Grátis' : 'R$ ' . number_format($freteValor, 2, ',', '.'),
                'aliexpress_url'  => $attributes['aliexpress_url'] ?? '',
            ]);
        }

        $this->session->setFlash('success', $msg);
        return Response::redirect($baseUrl . '/admin/dropship');
    }

    public function updateStatus(Request $request, string $id): ResponseInterface
    {
        $baseUrl = defined('BASE_URL') ? rtrim(BASE_URL, '/') : '';

        if (!$this->verifyCsrf($request)) {
            if ($this->isAjaxOrJson($request)) {
                return new JsonResponse(['success' => false, 'message' => 'Token de segurança expirado.'], 403);
            }
            $this->session->setFlash('error', 'Token de segurança expirado.');
            return Response::redirect($baseUrl . '/admin/dropship');
        }

        $productId = (int)$id;
        $product = $this->catalogRepo->findById($productId);
        if ($product === null) {
            if ($this->isAjaxOrJson($request)) {
                return new JsonResponse(['success' => false, 'message' => 'Produto não encontrado.'], 404);
            }
            $this->session->setFlash('error', 'Produto não encontrado.');
            return Response::redirect($baseUrl . '/admin/dropship');
        }

        $targetStatus = strtolower(trim((string)$request->input('status', 'published')));
        if (!in_array($targetStatus, ['published', 'draft', 'quarantine', 'review'], true)) {
            $targetStatus = 'published';
        }

        $normalizedStatus = ($targetStatus === 'quarantine' || $targetStatus === 'review') ? 'draft' : $targetStatus;
        $this->catalogRepo->updateStatus($productId, $normalizedStatus);

        $isLive = ($normalizedStatus === 'published');
        $msg = $isLive
            ? "✅ Produto '{$product->title}' carregado e ativo para venda no site!"
            : "⏳ Produto '{$product->title}' movido para Quarentena/Revisão (oculto da vitrine).";

        if ($this->isAjaxOrJson($request)) {
            return new JsonResponse([
                'success' => true,
                'message' => $msg,
                'status'  => $normalizedStatus,
                'is_live' => $isLive,
                'id'      => $productId,
            ]);
        }

        $this->session->setFlash('success', $msg);
        return Response::redirect($baseUrl . '/admin/dropship');
    }

    public function batchStatus(Request $request): ResponseInterface
    {
        $baseUrl = defined('BASE_URL') ? rtrim(BASE_URL, '/') : '';

        if (!$this->verifyCsrf($request)) {
            if ($this->isAjaxOrJson($request)) {
                return new JsonResponse(['success' => false, 'message' => 'Token de segurança expirado.'], 403);
            }
            $this->session->setFlash('error', 'Token de segurança expirado.');
            return Response::redirect($baseUrl . '/admin/dropship');
        }

        $rawIds = $request->input('ids');
        $ids = [];
        if (is_array($rawIds)) {
            $ids = array_values(array_filter(array_map('intval', $rawIds), fn($v) => $v > 0));
        } elseif (is_string($rawIds)) {
            $ids = array_values(array_filter(array_map('intval', explode(',', $rawIds)), fn($v) => $v > 0));
        }

        if (empty($ids)) {
            if ($this->isAjaxOrJson($request)) {
                return new JsonResponse(['success' => false, 'message' => 'Nenhum produto selecionado.'], 400);
            }
            $this->session->setFlash('warning', 'Nenhum produto selecionado.');
            return Response::redirect($baseUrl . '/admin/dropship');
        }

        $action = strtolower(trim((string)$request->input('action', 'publish')));
        $targetStatus = in_array($action, ['unpublish', 'draft', 'quarantine', 'review'], true) ? 'draft' : 'published';

        $updatedCount = $this->catalogRepo->batchUpdateStatus($ids, $targetStatus);

        $isLive = ($targetStatus === 'published');
        $msg = $isLive
            ? "🚀 {$updatedCount} produtos foram carregados com sucesso e já estão no ar no site!"
            : "⏸️ {$updatedCount} produtos foram movidos para Quarentena / Revisão (ocultos da vitrine).";

        if ($this->isAjaxOrJson($request)) {
            return new JsonResponse([
                'success'       => true,
                'message'       => $msg,
                'updated_count' => $updatedCount,
                'status'        => $targetStatus,
                'is_live'       => $isLive,
                'ids'           => $ids,
            ]);
        }

        $this->session->setFlash('success', $msg);
        return Response::redirect($baseUrl . '/admin/dropship');
    }

    public function batchDelete(Request $request): ResponseInterface
    {
        $baseUrl = defined('BASE_URL') ? rtrim(BASE_URL, '/') : '';

        if (!$this->verifyCsrf($request)) {
            if ($this->isAjaxOrJson($request)) {
                return new JsonResponse(['success' => false, 'message' => 'Token de segurança expirado.'], 403);
            }
            $this->session->setFlash('error', 'Token de segurança expirado.');
            return Response::redirect($baseUrl . '/admin/dropship');
        }

        $rawIds = $request->input('ids');
        $ids = [];
        if (is_array($rawIds)) {
            $ids = array_values(array_filter(array_map('intval', $rawIds), fn($v) => $v > 0));
        } elseif (is_string($rawIds)) {
            $ids = array_values(array_filter(array_map('intval', explode(',', $rawIds)), fn($v) => $v > 0));
        }

        if (empty($ids)) {
            if ($this->isAjaxOrJson($request)) {
                return new JsonResponse(['success' => false, 'message' => 'Nenhum produto selecionado para exclusão.'], 400);
            }
            $this->session->setFlash('warning', 'Nenhum produto selecionado para exclusão.');
            return Response::redirect($baseUrl . '/admin/dropship');
        }

        $deletedCount = $this->catalogRepo->batchDelete($ids, preserveOrdered: true);
        $msg = "🗑️ {$deletedCount} produtos foram excluídos do catálogo com sucesso!";

        if ($this->isAjaxOrJson($request)) {
            return new JsonResponse([
                'success'       => true,
                'message'       => $msg,
                'deleted_count' => $deletedCount,
                'ids'           => $ids,
            ]);
        }

        $this->session->setFlash('success', $msg);
        return Response::redirect($baseUrl . '/admin/dropship');
    }

    public function toggleDailyCycle(Request $request): ResponseInterface
    {
        $baseUrl = defined('BASE_URL') ? rtrim(BASE_URL, '/') : '';

        if (!$this->verifyCsrf($request)) {
            if ($this->isAjaxOrJson($request)) {
                return new JsonResponse(['success' => false, 'message' => 'Token de segurança expirado.'], 403);
            }
            $this->session->setFlash('error', 'Token de segurança expirado.');
            return Response::redirect($baseUrl . '/admin/dropship');
        }

        $config = $this->loadConfig();
        $current = !empty($config['auto_sync_enabled'] ?? true);
        $newStatus = !$current;
        $config['auto_sync_enabled'] = $newStatus;
        $this->saveConfig($config);

        $statusLabel = $newStatus ? 'ativada' : 'pausada / desabilitada';
        $msg = "⚡ Rotação Automática de 24h foi {$statusLabel} com sucesso!";

        if ($this->isAjaxOrJson($request)) {
            return new JsonResponse([
                'success'           => true,
                'message'           => $msg,
                'auto_sync_enabled' => $newStatus,
                'status_label'      => $statusLabel,
            ]);
        }

        $this->session->setFlash('success', $msg);
        return Response::redirect($baseUrl . '/admin/dropship');
    }

    private function isAjaxOrJson(Request $request): bool
    {
        $serverAjax = !empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower((string)$_SERVER['HTTP_X_REQUESTED_WITH']) === 'xmlhttprequest';
        $serverFetch = !empty($_SERVER['HTTP_SEC_FETCH_DEST']) && $_SERVER['HTTP_SEC_FETCH_DEST'] === 'empty';
        $serverAccept = !empty($_SERVER['HTTP_ACCEPT']) && str_contains($_SERVER['HTTP_ACCEPT'], 'application/json');
        $reqIsAjax = method_exists($request, 'isAjax') && $request->isAjax();
        $hasHeader = method_exists($request, 'header');

        return $serverAjax
            || $serverFetch
            || $serverAccept
            || $reqIsAjax
            || (bool)$request->input('ajax', false)
            || ($hasHeader && str_contains((string)$request->header('Accept', ''), 'application/json'))
            || ($hasHeader && strtolower((string)$request->header('X-Requested-With', '')) === 'xmlhttprequest')
            || ($hasHeader && (string)$request->header('Sec-Fetch-Dest', '') === 'empty');
    }

    private function parseCurrency(mixed $value): float
    {
        if ($value === null || is_array($value) || is_object($value)) {
            return 0.0;
        }
        if (is_numeric($value)) {
            return (float)$value;
        }
        $str = trim((string)$value);
        $str = str_replace(['R$', '$', ' '], '', $str);

        if (str_contains($str, ',')) {
            // Formato brasileiro: 1.234,56 -> remove pontos, substitui vírgula por ponto
            $str = str_replace('.', '', $str);
            $str = str_replace(',', '.', $str);
        }

        return (float)$str;
    }

    public function runDailyCycle(Request $request): ResponseInterface
    {
        $baseUrl = defined('BASE_URL') ? rtrim(BASE_URL, '/') : '';

        if (!$this->verifyCsrf($request)) {
            if ($this->isAjaxOrJson($request)) {
                return new Response(json_encode(['success' => false, 'error' => 'Token CSRF inválido']), 403, ['Content-Type' => 'application/json']);
            }
            $this->session->setFlash('error', 'Token de segurança expirado. Tente novamente.');
            return new Response('', 302, ['Location' => $baseUrl . '/admin/dropship']);
        }

        try {
            $itemsPerCategory = max(1, min(20, (int)$request->input('items_per_category', 10)));
            $warehouseOrigin = strtoupper(trim((string)$request->input('warehouse_origin', 'ALL')));
            if (!in_array($warehouseOrigin, ['ALL', 'BR', 'CN'], true)) {
                $warehouseOrigin = 'ALL';
            }
            $result = $this->miningService->runDailyAutomatedRotation($itemsPerCategory, $warehouseOrigin);
            $cycleInfo = $this->miningService->getDailyCycleInfo();

            if ($this->isAjaxOrJson($request)) {
                return new Response(json_encode([
                    'success' => true,
                    'message' => "Ciclo diário 24h finalizado com sucesso! Total minerado: {$result['total_mined']} produtos.",
                    'result'  => $result,
                    'cycle'   => $cycleInfo,
                ]), 200, ['Content-Type' => 'application/json']);
            }

            $this->session->setFlash('success', "Ciclo diário 24h concluído com sucesso! {$result['total_mined']} novos produtos minerados nas 9 categorias oficiais.");
        } catch (Throwable $e) {
            if ($this->isAjaxOrJson($request)) {
                return new Response(json_encode(['success' => false, 'error' => $e->getMessage()]), 500, ['Content-Type' => 'application/json']);
            }
            $this->session->setFlash('error', "Falha ao executar ciclo diário: " . $e->getMessage());
        }

        return new Response('', 302, ['Location' => $baseUrl . '/admin/dropship']);
    }

    public function clearCatalog(Request $request): ResponseInterface
    {
        $baseUrl = defined('BASE_URL') ? rtrim(BASE_URL, '/') : '';

        if (!$this->verifyCsrf($request)) {
            $this->session->setFlash('error', 'Token de segurança expirado.');
            return Response::redirect($baseUrl . '/admin/dropship');
        }

        $action = (string)$request->input('action', 'clear_all');
        try {
            if ($action === 'purge_drafts') {
                $count = $this->catalogRepo->purgeDrafts();
                $this->session->setFlash('success', "🗑️ {$count} produtos em rascunho / despublicados foram removidos do catálogo.");
            } else {
                $count = $this->catalogRepo->clearAll(preserveOrdered: true);
                $this->session->setFlash('success', "✔️ Catálogo limpo com sucesso! {$count} produtos foram removidos. (Produtos com pedidos ativos foram preservados).");
            }
        } catch (Throwable $e) {
            $this->session->setFlash('error', "Falha ao limpar catálogo: " . $e->getMessage());
        }

        return Response::redirect($baseUrl . '/admin/dropship');
    }

    public function publishDrafts(Request $request): ResponseInterface
    {
        $baseUrl = defined('BASE_URL') ? rtrim(BASE_URL, '/') : '';

        if (!$this->verifyCsrf($request)) {
            $this->session->setFlash('error', 'Token de segurança expirado.');
            return Response::redirect($baseUrl . '/admin/dropship');
        }

        try {
            $count = $this->catalogRepo->publishAll();
            $this->session->setFlash('success', "📢 {$count} produtos foram publicados e ativados para venda na loja!");
        } catch (Throwable $e) {
            $this->session->setFlash('error', "Falha ao publicar rascunhos: " . $e->getMessage());
        }

        return Response::redirect($baseUrl . '/admin/dropship');
    }

    public function acquireNew(Request $request): ResponseInterface
    {
        $baseUrl = defined('BASE_URL') ? rtrim(BASE_URL, '/') : '';

        if (!$this->verifyCsrf($request)) {
            $this->session->setFlash('error', 'Token de segurança expirado.');
            return Response::redirect($baseUrl . '/admin/dropship');
        }

        $replaceCatalog = (bool)$request->input('replace_catalog', true);
        $itemsPerCategory = max(1, min(20, (int)$request->input('items_per_category', 10)));
        $warehouseOrigin = strtoupper(trim((string)$request->input('warehouse_origin', 'ALL')));
        if (!in_array($warehouseOrigin, ['ALL', 'BR', 'CN'], true)) {
            $warehouseOrigin = 'ALL';
        }

        try {
            $purgedCount = 0;
            if ($replaceCatalog) {
                $purgedCount = $this->catalogRepo->clearAll(preserveOrdered: true);
            }

            $result = $this->miningService->runDailyAutomatedRotation($itemsPerCategory, $warehouseOrigin);

            // Garante que todos os produtos minerados estejam 100% ativos para venda
            $this->catalogRepo->publishAll();

            $totalMined = (int)($result['total_mined'] ?? 0);
            $msg = "🚀 Aquisição concluída com sucesso! {$totalMined} novos produtos oficiais ativos em venda para as próximas 24 horas.";
            if ($purgedCount > 0) {
                $msg .= " ({$purgedCount} produtos antigos foram limpos previamente).";
            }
            $this->session->setFlash('success', $msg);
        } catch (Throwable $e) {
            $this->session->setFlash('error', "Falha ao adquirir novos produtos: " . $e->getMessage());
        }

        return Response::redirect($baseUrl . '/admin/dropship');
    }

    /**
     * Mineração Progressiva em Lote por Categoria (AJAX Step-by-Step).
     * Evita timeout 504 Gateway Time-out na Hostinger executando cada categoria em 2-4 segundos.
     */
    public function mineCategoryStep(Request $request): ResponseInterface
    {
        if (!$this->verifyCsrf($request)) {
            return new Response(json_encode(['success' => false, 'error' => 'Token CSRF inválido ou expirado.']), 403, ['Content-Type' => 'application/json']);
        }

        try {
            $category = trim((string)$request->input('category', 'Eletrônicos & Gadget'));
            $itemsPerCategory = max(1, min(20, (int)$request->input('items_per_category', 10)));
            $replaceCatalog = (bool)$request->input('replace_catalog', false);
            $warehouseOrigin = strtoupper(trim((string)$request->input('warehouse_origin', 'ALL')));
            if (!in_array($warehouseOrigin, ['ALL', 'BR', 'CN'], true)) {
                $warehouseOrigin = 'ALL';
            }
            $sendToQuarantine = (bool)$request->input('quarantine', false);

            $purgedCount = 0;
            if ($replaceCatalog) {
                $purgedCount = $this->catalogRepo->clearAll(preserveOrdered: true);
            }

            // Minera apenas a categoria solicitada no entreposto selecionado
            $mined = $this->miningService->mineTrendingProducts(
                category: $category,
                limit: $itemsPerCategory,
                autoPersist: true,
                sort: 'volume_desc',
                warehouseOrigin: $warehouseOrigin
            );
            $count = count($mined);

            if ($sendToQuarantine) {
                $minedIds = array_filter(array_map(fn($p) => (int)($p->id ?? 0), $mined));
                if (!empty($minedIds)) {
                    $this->catalogRepo->batchUpdateStatus($minedIds, 'draft');
                }
            } else {
                $this->catalogRepo->publishAll();
            }
            $totalCatalog = $this->catalogRepo->count();

            return new Response(json_encode([
                'success'          => true,
                'category'         => $category,
                'mined_count'      => $count,
                'quarantine'       => $sendToQuarantine,
                'purged_count'     => $purgedCount,
                'total_in_catalog' => $totalCatalog,
            ]), 200, ['Content-Type' => 'application/json']);
        } catch (Throwable $e) {
            return new Response(json_encode([
                'success' => false,
                'error'   => $e->getMessage(),
            ]), 500, ['Content-Type' => 'application/json']);
        }
    }

    /**
     * Finaliza o ciclo diário de 24 horas atualizando o timestamp de rotação.
     */
    public function finishDailyCycle(Request $request): ResponseInterface
    {
        if (!$this->verifyCsrf($request)) {
            return new Response(json_encode(['success' => false, 'error' => 'Token CSRF inválido']), 403, ['Content-Type' => 'application/json']);
        }

        try {
            $now = time();
            $this->miningService->updateConfigField('last_daily_cycle_at', $now);
            $cycleInfo = $this->miningService->getDailyCycleInfo();

            return new Response(json_encode([
                'success' => true,
                'message' => 'Ciclo diário 24h finalizado com sucesso!',
                'cycle'   => $cycleInfo,
            ]), 200, ['Content-Type' => 'application/json']);
        } catch (Throwable $e) {
            return new Response(json_encode([
                'success' => false,
                'error'   => $e->getMessage(),
            ]), 500, ['Content-Type' => 'application/json']);
        }
    }

    /**
     * Gestão Administrativa de Clientes Cadastrados (semelhante a Alunos & Matrículas do Academy).
     */
    public function customers(Request $request): ResponseInterface
    {
        $baseUrl = defined('BASE_URL') ? rtrim(BASE_URL, '/') : '';
        $search = trim((string)$request->input('q', ''));
        $status = trim((string)$request->input('status', 'all'));
        $page = max(1, (int)$request->input('page', 1));
        $perPage = 15;

        $customers = [];
        $total = 0;
        $metrics = [
            'total_customers'     => 0,
            'active_customers'    => 0,
            'suspended_customers' => 0,
            'linked_orders'       => 0,
        ];

        if ($this->customerRepo !== null) {
            if (method_exists($this->customerRepo, 'listCustomers')) {
                $res = $this->customerRepo->listCustomers(
                    $page,
                    $perPage,
                    $search !== '' ? $search : null,
                    $status !== 'all' ? $status : null
                );
                $customers = $res['items'] ?? [];
                $total = (int)($res['total'] ?? count($customers));
            } else {
                $customers = $this->customerRepo->listAll($perPage, ($page - 1) * $perPage);
                $total = count($customers);
            }

            if (method_exists($this->customerRepo, 'getCustomerMetrics')) {
                $metrics = $this->customerRepo->getCustomerMetrics();
            }
        }

        $totalPages = max(1, (int)ceil($total / $perPage));
        $csrfToken = (string)$this->session->getCsrfToken();
        $flash = $this->session->getFlash();
        $currentSearch = $search;
        $currentStatus = $status;
        $recentDisputes = ($this->disputeRepo !== null && method_exists($this->disputeRepo, 'listRecent'))
            ? $this->disputeRepo->listRecent(30)
            : [];

        ob_start();
        include dirname(__DIR__) . '/views/admin/customers.php';
        $content = (string)ob_get_clean();

        return new ViewResponse($content, true);
    }

    /**
     * Ativa ou suspende a conta de um cliente cadastrado no DomainDrop.
     */
    public function updateCustomerStatus(Request $request, string $id): ResponseInterface
    {
        $baseUrl = defined('BASE_URL') ? rtrim(BASE_URL, '/') : '';

        if (!$this->verifyCsrf($request)) {
            $this->session->setFlash('error', 'Token de segurança expirado. Tente novamente.');
            return Response::redirect($baseUrl . '/admin/dropship/customers');
        }

        $customerId = (int)$id;
        $newStatus = trim((string)$request->input('status', 'active'));
        if (!in_array($newStatus, ['active', 'suspended', 'blocked'], true)) {
            $newStatus = 'active';
        }

        if ($this->customerRepo !== null && method_exists($this->customerRepo, 'updateStatus')) {
            $this->customerRepo->updateStatus($customerId, $newStatus);
            $label = $newStatus === 'active' ? 'ativado' : 'suspenso';
            $this->session->setFlash('success', "Status do cliente #{$customerId} atualizado ({$label}).");
        } else {
            $this->session->setFlash('error', 'Repositório de clientes não disponível.');
        }

        return Response::redirect($baseUrl . '/admin/dropship/customers');
    }

    /**
     * Tela de Inteligência de Demanda e Livro de Presença: GET /admin/dropship/demand
     */
    public function demandLedger(Request $request): ResponseInterface
    {
        $baseUrl = defined('BASE_URL') ? rtrim(BASE_URL, '/') : '';
        $selectedPeriod = trim((string)$request->input('period', date('Y-m')));
        if (!preg_match('/^\d{4}-\d{2}$/', $selectedPeriod)) {
            $selectedPeriod = date('Y-m');
        }

        $livePulse = $this->metricsRepo ? $this->metricsRepo->getLivePulseMetrics() : [
            'period'                => date('Y-m'),
            'active_products_count' => 0,
            'total_detail_clicks'   => 0,
            'total_buy_clicks'      => 0,
            'total_conversions'     => 0,
            'total_demand_score'    => 0,
            'top_products'          => [],
        ];

        $rankings = $this->metricsRepo ? $this->metricsRepo->getMonthlyRankings($selectedPeriod, 30) : [];
        $categoryProfile = $this->metricsRepo ? $this->metricsRepo->getAudienceCategoryProfile($selectedPeriod) : [];

        // Prioriza leitura em JSON estruturado mensal (sem poluir o banco relacional)
        if ($this->logStorage !== null) {
            try { $this->logStorage->purgeExpiredLogs(2); } catch (\Throwable $e) {}
            $recentActivities = $this->logStorage->getRecentInteractions($selectedPeriod, 50);
        } else {
            $recentActivities = $this->metricsRepo ? $this->metricsRepo->getRecentActivityLogs(50) : [];
        }

        $csrfToken = (string)$this->session->getCsrfToken();

        ob_start();
        include dirname(__DIR__) . '/views/admin/demand.php';
        $content = ob_get_clean();

        return new ViewResponse($content ?: '');
    }

    private function verifyCsrf(Request $request): bool
    {
        $token = (string)$request->input('csrf_token', (string)$request->input('_csrf', (string)($request->server['HTTP_X_CSRF_TOKEN'] ?? '')));
        $expected = (string)$this->session->getCsrfToken();
        return $token !== '' && hash_equals($expected, $token);
    }

    /**
     * Gera um state OAuth2 assinado criptograficamente com HMAC-SHA256 e timestamp (Claude Audit Item 1).
     * Imune à perda de sessão decorrente de redirecionamentos cross-site (SameSite Lax/Strict).
     */
    public function generateSignedState(string $appSecret): string
    {
        $nonce = bin2hex(random_bytes(16));
        $timestamp = (string)time();
        $payload = $nonce . '.' . $timestamp;
        $sig = hash_hmac('sha256', $payload, $appSecret);
        return $payload . '.' . $sig;
    }

    /**
     * Valida um state assinado com checagem de assinatura HMAC-SHA256 e TTL (padrão 600 segundos / 10 minutos).
     */
    public function verifySignedState(string $state, string $appSecret, int $ttl = 600): bool
    {
        if ($state === '' || $appSecret === '') {
            return false;
        }

        $parts = explode('.', $state);
        if (count($parts) !== 3) {
            return false;
        }

        $nonce = (string)$parts[0];
        $timestampStr = (string)$parts[1];
        $sig = (string)$parts[2];
        if (!ctype_digit($timestampStr)) {
            return false;
        }

        $timestamp = (int)$timestampStr;
        $now = time();
        if ($timestamp < ($now - $ttl) || $timestamp > ($now + 60)) {
            return false;
        }

        $payload = $nonce . '.' . $timestampStr;
        $expectedSig = hash_hmac('sha256', $payload, $appSecret);

        return hash_equals($expectedSig, $sig);
    }

    private function loadConfig(): array
    {
        $config = \DomainSystem\Plugins\domain_drop\Services\AtomicConfigStorage::read($this->configFile);
        if (!empty($config)) {
            return $config;
        }
        return [
            'app_key' => '558628',
            'app_secret' => '',
            'default_markup_percent' => 30.0,
            'min_profit_margin_brl' => 10.0,
        ];
    }

    public function saveConfig(array $config): void
    {
        $saved = \DomainSystem\Plugins\domain_drop\Services\AtomicConfigStorage::write($this->configFile, $config);
        if (!$saved) {
            $dir = dirname($this->configFile);
            @chmod($dir, 0775);
            @chmod($this->configFile, 0664);
            $saved = \DomainSystem\Plugins\domain_drop\Services\AtomicConfigStorage::write($this->configFile, $config);
        }
        if (!$saved) {
            throw new \RuntimeException("Permissão negada ao gravar '{$this->configFile}'. Verifique as permissões de escrita na pasta 'config/plugins/'.");
        }
    }
}
