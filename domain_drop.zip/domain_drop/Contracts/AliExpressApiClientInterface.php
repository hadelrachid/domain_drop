<?php

declare(strict_types=1);

namespace DomainSystem\Plugins\domain_drop\Contracts;

/**
 * Contrato de comunicação com a AliExpress Open Platform API (DIP / SOLID).
 */
interface AliExpressApiClientInterface
{
    /**
     * Executa uma chamada oficial ao gateway da AliExpress Open Platform.
     * 
     * @param string $apiMethod Nome oficial do método (ex: 'aliexpress.ds.product.get')
     * @param array<string, mixed> $params Parâmetros específicos da API
     * @param string|null $accessToken Token OAuth2 de sessão (opcional)
     * @return array<string, mixed> Resposta decodificada em array
     */
    public function execute(string $apiMethod, array $params = [], ?string $accessToken = null): array;

    /**
     * Retorna o último erro ocorrido em chamadas à API, se houver.
     */
    public function getLastError(): ?string;

    /**
     * Consulta detalhes completos de um produto pelo ID do AliExpress.
     * 
     * @param string|int $productId ID numérico do produto no AliExpress
     * @param string $targetLanguage Idioma desejado (padrão 'pt')
     * @param string $targetCurrency Moeda base (padrão 'USD')
     * @return array<string, mixed>
     */
    public function getProductDetails(string|int $productId, string $targetLanguage = 'pt', string $targetCurrency = 'USD'): array;

    /**
     * Pesquisa ou minera produtos em alta por termo ou categoria.
     * 
     * @param array<string, mixed> $filters
     * @return array<int, array<string, mixed>>
     */
    public function searchProducts(array $filters = []): array;

    /**
     * Consulta lista de IDs de produtos mais vendidos no feed oficial de Dropshipping.
     * Endpoint oficial: aliexpress.ds.feed.itemids.get (dropshiper.pdf páginas 950-1010).
     *
     * @param string $feedName Nome do feed (padrão 'DS bestseller')
     * @param string|null $categoryId ID da categoria de primeiro nível no AliExpress
     * @param int $pageSize Quantidade de itens por página (máx. 200)
     * @param string|null $searchId Cursor de paginação retornado na busca anterior
     * @return array<string, mixed> Estrutura com 'products' (array de IDs), 'total' e 'search_id'
     */
    public function getFeedItemIds(string $feedName = 'DS bestseller', ?string $categoryId = null, int $pageSize = 50, ?string $searchId = null): array;

    /**
     * Consulta os nomes de feeds de recomendação e bestsellers disponíveis no AliExpress.
     * Endpoint oficial: aliexpress.ds.feedname.get (dropshiper.pdf).
     *
     * @return array<int, string> Lista de nomes de feeds oficiais disponíveis
     */
    public function getFeedNames(): array;

    /**
     * Realiza busca textual dropshipping oficial via aliexpress.ds.text.search (dropshiper.pdf páginas 39-41 / 1938-2025).
     * Não exige session token obrigatório.
     *
     * @param array<string, mixed> $filters
     * @return array<string, mixed>
     */
    public function textSearch(array $filters = []): array;

    /**
     * Consulta eventos logísticos e rastreamento oficial de um envio no SDK AliExpress.
     *
     * @param string $logisticsNo Código de rastreio da transportadora (Correios/Cainiao)
     * @param string $origin Origem da ordem no AliExpress (padrão 'ESCROW')
     * @param string $outRef ID do pedido no AliExpress
     * @param string $serviceName Serviço logístico / transportadora (ex: 'CAINIAO', 'CORREIOS')
     * @param string $toArea País de destino ISO-2 (padrão 'BR')
     * @return array<string, mixed>
     */
    public function queryTrackingInfo(
        string $logisticsNo,
        string $origin = 'ESCROW',
        string $outRef = '',
        string $serviceName = 'CAINIAO',
        string $toArea = 'BR'
    ): array;

    /**
     * Consulta a lista e árvore oficial de categorias diretamente da AliExpress Open Platform.
     *
     * @param int|string $categoryId ID da categoria pai (0 para todas as categorias raiz e árvore completa)
     * @param string $language Idioma oficial retornado pelo AliExpress (padrão 'pt')
     * @param bool $forceRefresh Se verdadeiro, ignora o cache local e busca na API remota
     * @return array<int, array<string, mixed>>
     */
    public function getOfficialCategories(int|string $categoryId = 0, string $language = 'pt', bool $forceRefresh = false): array;

    /**
     * Consulta atributos de SKU de uma categoria oficial para vendedores e dropshippers internacionais.
     * Endpoint oficial: aliexpress.solution.sku.attribute.query (categoria-e-atributos.pdf).
     *
     * @param int|string $categoryId
     * @return array<string, mixed>
     */
    public function getSkuAttributes(int|string $categoryId): array;

    /**
     * Consulta dados e validação de código de barras oficial EAN / GTIN de um produto ou variação.
     * Endpoint oficial: aliexpress.product.eancode.info.query (ae-ean-code.pdf).
     *
     * @param string $eanCode
     * @return array<string, mixed>
     */
    public function getProductEanCode(string $eanCode): array;

    /**
     * Consulta opções de frete, método de entrega, país de despacho (ship_from_country) e estoque.
     * Endpoint oficial: aliexpress.ds.freight.query (documentacao-completa.pdf - Pág. 229-230).
     *
     * @param array<string, mixed> $deliveryReq Estrutura queryDeliveryReq (productId, shipToCountry, selectedSkuId, etc.)
     * @return array<string, mixed>
     */
    public function queryFreight(array $deliveryReq): array;

    /**
     * Consulta o estoque real por depósito e variações de SKU de um produto.
     * Endpoint oficial: aliexpress.solution.product.inventory.query (ae-product-management.pdf).
     *
     * @param int|string $productId
     * @return array<string, mixed>
     */
    public function queryProductInventory(int|string $productId): array;

    /**
     * Atualização em lote de preços de produtos e variações de SKU (até 20 itens por requisição).
     * Endpoint oficial: aliexpress.solution.batch.product.price.update (ae-product-management.pdf).
     *
     * @param array<int, array<string, mixed>> $priceUpdates
     * @return array<string, mixed>
     */
    public function updateBatchProductPrices(array $priceUpdates): array;

    /**
     * Gera a URL de autorização OAuth2 oficial do AliExpress.
     */
    public function getOAuthAuthorizeUrl(string $redirectUri, string $state = ''): string;

    /**
     * Troca o código de autorização OAuth2 por access_token e refresh_token.
     *
     * @return array<string, mixed>
     */
    public function createAccessToken(string $code): array;

    /**
     * Renova o access_token utilizando o refresh_token via OAuth2.
     *
     * @return array<string, mixed>
     */
    public function refreshAccessToken(string $refreshToken): array;
}
