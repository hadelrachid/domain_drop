<?php

declare(strict_types=1);

namespace DomainSystem\Plugins\domain_drop\Services;

use DomainSystem\Plugins\domain_drop\Contracts\AliExpressApiClientInterface;
use DomainSystem\Plugins\domain_drop\Exceptions\AliExpressApiException;
use RuntimeException;
use Throwable;

/**
 * Cliente Oficial de Comunicação com a AliExpress Open Platform API (DIP / SOLID).
 * 
 * Implementa o protocolo de assinatura criptográfica oficial HMAC-SHA256 (IOP Protocol),
 * compatível com o gateway internacional: https://api-sg.aliexpress.com/sync.
 */
class AliExpressApiClient implements AliExpressApiClientInterface
{
    private string $appKey;
    private string $appSecret;
    private string $gatewayUrl;
    private int $timeout;
    private string $sdkVersion = 'iop-sdk-php-20220608';
    private ?string $lastError = null;

    public function __construct(
        string $appKey,
        string $appSecret,
        string $gatewayUrl = 'https://api-sg.aliexpress.com/sync',
        int $timeout = 15,
        private ?string $accessToken = null
    ) {
        $this->appKey = trim($appKey);
        $this->appSecret = trim($appSecret);
        $this->gatewayUrl = rtrim($gatewayUrl, '/');
        $this->timeout = $timeout;
    }

    public function getLastError(): ?string
    {
        return $this->lastError;
    }

    public function execute(string $apiMethod, array $params = [], ?string $accessToken = null): array
    {
        if ($this->appKey === '' || $this->appSecret === '') {
            throw new RuntimeException('[AliExpressApiClient] AppKey ou AppSecret não configurados no DomainDrop.');
        }

        $token = $accessToken ?? $this->accessToken;

        $sysParams = [
            'app_key'     => $this->appKey,
            'sign_method' => 'sha256',
            'timestamp'   => $this->getMillisecondTimestamp(),
            'method'      => $apiMethod,
            'partner_id'  => $this->sdkVersion,
            'format'      => 'json',
            'simplify'    => 'true',
            'v'           => '2.0',
        ];

        if ($token !== null && $token !== '') {
            $sysParams['session'] = $token;
        }

        // Filtra parâmetros nulos ou de string vazia para manter paridade exata com o cálculo de assinatura IOP
        $cleanParams = [];
        foreach ($params as $k => $v) {
            if ($v !== null && $v !== '') {
                $cleanParams[$k] = (string)$v;
            }
        }

        // Combina parâmetros de sistema e de API para cálculo da assinatura
        $allParams = array_merge($cleanParams, $sysParams);
        $sysParams['sign'] = $this->generateSignature($apiMethod, $allParams);

        // Monta a Query String dos parâmetros de sistema
        $requestUrl = $this->gatewayUrl . '?' . http_build_query($sysParams);

        return $this->sendHttpRequest($requestUrl, $cleanParams);
    }

    public function getOAuthAuthorizeUrl(string $redirectUri, string $state = ''): string
    {
        $query = [
            'response_type' => 'code',
            'force_auth'    => 'true',
            'redirect_uri'  => $redirectUri,
            'client_id'     => $this->appKey,
        ];
        if ($state !== '') {
            $query['state'] = $state;
        }
        return 'https://api-sg.aliexpress.com/oauth/authorize?' . http_build_query($query);
    }

    /**
     * Troca o código OAuth (`code`) pelo `access_token` e `refresh_token` via `/rest/auth/token/create`.
     *
     * @return array<string, mixed>
     */
    public function createAccessToken(string $code): array
    {
        $raw = $this->executeRest('/auth/token/create', ['code' => trim($code)]);
        $unwrapped = \DomainSystem\Plugins\domain_drop\ValueObjects\AliExpressToken::unwrapPayload($raw);
        return array_merge($raw, $unwrapped);
    }

    /**
     * Renova o `access_token` usando o `refresh_token` via `/rest/auth/token/refresh`.
     *
     * @return array<string, mixed>
     */
    public function refreshAccessToken(string $refreshToken): array
    {
        $raw = $this->executeRest('/auth/token/refresh', ['refresh_token' => trim($refreshToken)]);
        $unwrapped = \DomainSystem\Plugins\domain_drop\ValueObjects\AliExpressToken::unwrapPayload($raw);
        return array_merge($raw, $unwrapped);
    }

    /**
     * Executa chamada IOP System/Auth (`/rest/...`), onde o caminho da API é incluído no cálculo HMAC-SHA256.
     * Segue estritamente a especificação oficial do AliExpress IOP SDK (IopClient).
     *
     * @param array<string, mixed> $params
     * @return array<string, mixed>
     */
    public function executeRest(string $apiPath, array $params = []): array
    {
        if ($this->appKey === '' || $this->appSecret === '') {
            throw new RuntimeException('[AliExpressApiClient] AppKey ou AppSecret não configurados no DomainDrop.');
        }

        $cleanPath = '/' . ltrim($apiPath, '/');
        $cleanParams = [];
        foreach ($params as $k => $v) {
            if ($v !== null && $v !== '') {
                $cleanParams[$k] = (string)$v;
            }
        }

        $sysParams = [
            'app_key'     => $this->appKey,
            'sign_method' => 'sha256',
            'timestamp'   => $this->getMillisecondTimestamp(),
            'method'      => $cleanPath,
            'partner_id'  => $this->sdkVersion,
            'format'      => 'json',
            'simplify'    => 'false',
        ];

        $allParams = array_merge($cleanParams, $sysParams);
        $sysParams['sign'] = $this->generateSignature($cleanPath, $allParams);

        $restBase = str_ends_with($this->gatewayUrl, '/sync')
            ? substr($this->gatewayUrl, 0, -5) . '/rest'
            : (str_ends_with($this->gatewayUrl, '/rest') ? $this->gatewayUrl : 'https://api-sg.aliexpress.com/rest');

        $requestUrl = rtrim($restBase, '/') . '?' . http_build_query($sysParams);
        return $this->sendHttpRequest($requestUrl, $cleanParams);
    }

    public function getProductDetails(string|int $productId, string $targetLanguage = 'pt', string $targetCurrency = 'USD'): array
    {
        $numericId = (string)$productId;
        // Se for URL completa do AliExpress, extrai o ID numérico
        if (preg_match('/\/item\/(\d+)\.html/', $numericId, $matches)) {
            $numericId = $matches[1];
        }

        $params = [
            'product_id'      => $numericId,
            'target_language' => $targetLanguage,
            'target_currency' => $targetCurrency,
            'ship_to_country' => 'BR',
        ];

        return $this->execute('aliexpress.ds.product.get', $params, $this->accessToken);
    }

    /**
     * Realiza busca textual dropshipping oficial via aliexpress.ds.text.search (dropshiper.pdf páginas 39-41).
     * Não exige session token obrigatório.
     *
     * @param array<string, mixed> $filters
     * @return array<string, mixed>
     */
    public function textSearch(array $filters = []): array
    {
        $sort = (string)($filters['sort_by'] ?? ($filters['sort'] ?? 'orders,desc'));
        $mappedSort = match ($sort) {
            'min_price,asc', 'price_asc'   => 'min_price,asc',
            'min_price,desc', 'price_desc' => 'min_price,desc',
            'comments,desc', 'rating'      => 'comments,desc',
            default                        => 'orders,desc',
        };

        $params = [
            'local'       => (string)($filters['local'] ?? 'pt_BR'),
            'countryCode' => (string)($filters['country_code'] ?? ($filters['countryCode'] ?? ($filters['country'] ?? 'BR'))),
            'sortBy'      => $mappedSort,
            'pageSize'    => (string)($filters['page_size'] ?? ($filters['pageSize'] ?? '20')),
            'pageIndex'   => (string)($filters['page_index'] ?? ($filters['pageIndex'] ?? ($filters['page_no'] ?? '1'))),
            'currency'    => (string)($filters['currency'] ?? 'BRL'),
        ];

        $keyword = trim((string)($filters['keyWord'] ?? ($filters['keyword'] ?? ($filters['query'] ?? ($filters['key_word'] ?? '')))));
        if ($keyword !== '') {
            $params['keyWord'] = $keyword;
        }

        $categoryId = $filters['categoryId'] ?? ($filters['category_id'] ?? ($filters['cate_id'] ?? null));
        if (!empty($categoryId)) {
            $params['categoryId'] = (string)$categoryId;
        }

        if (!empty($filters['ship_from_country'])) {
            $params['ship_from_country'] = (string)$filters['ship_from_country'];
            $params['shipFrom'] = (string)$filters['ship_from_country'];
        }

        try {
            $response = $this->execute('aliexpress.ds.text.search', $params, $this->accessToken);
            $this->lastError = null;
            return $response;
        } catch (Throwable $e) {
            // Se falhar com token de sessão inválido, tenta sem token (aliexpress.ds.text.search é público no dropshiper.docx)
            if ($this->accessToken !== null && $this->accessToken !== '') {
                try {
                    $response = $this->execute('aliexpress.ds.text.search', $params, null);
                    $this->lastError = null;
                    return $response;
                } catch (Throwable $e2) {
                    $this->lastError = $e2->getMessage();
                }
            } else {
                $this->lastError = $e->getMessage();
            }
            error_log("[AliExpressApiClient] textSearch falhou: " . $this->lastError);
            return [];
        }
    }

    /**
     * Consulta lista de IDs de produtos mais vendidos no feed oficial de Dropshipping.
     * Endpoint oficial: aliexpress.ds.feed.itemids.get (dropshiper.pdf páginas 950-1010).
     *
     * @param string $feedName Nome do feed (padrão 'DS bestseller')
     * @param string|null $categoryId ID da categoria de primeiro nível no AliExpress
     * @param int $pageSize Quantidade de itens por página (máx. 200)
     * @param string|null $searchId Cursor de paginação retornado na busca anterior
     * @return array<string, mixed> Estrutura com 'products' (array de IDs), 'total' e 'search_id'
     */
    public function getFeedItemIds(string $feedName = 'DS bestseller', ?string $categoryId = null, int $pageSize = 50, ?string $searchId = null): array
    {
        $params = [
            'feed_name' => $feedName !== '' ? $feedName : 'DS bestseller',
            'page_size' => (string)min(max($pageSize, 1), 200),
        ];

        if ($categoryId !== null && trim((string)$categoryId) !== '') {
            $params['category_id'] = trim((string)$categoryId);
        }

        if ($searchId !== null && trim($searchId) !== '') {
            $params['search_id'] = trim($searchId);
        }

        try {
            $response = $this->execute('aliexpress.ds.feed.itemids.get', $params, $this->accessToken);
            $this->lastError = null;

            $unwrapped = \DomainSystem\Plugins\domain_drop\ValueObjects\AliExpressToken::unwrapPayload($response);
            $result = $unwrapped['result'] ?? ($response['result'] ?? $unwrapped);

            $rawProducts = $result['products'] ?? [];
            if (is_string($rawProducts)) {
                $decoded = json_decode($rawProducts, true);
                if (is_array($decoded)) {
                    $rawProducts = $decoded;
                }
            }

            return [
                'total'     => (int)($result['total'] ?? (is_array($rawProducts) ? count($rawProducts) : 0)),
                'products'  => is_array($rawProducts) ? $rawProducts : [],
                'search_id' => (string)($result['search_id'] ?? ''),
                'raw'       => $response,
            ];
        } catch (Throwable $e) {
            $this->lastError = $e->getMessage();
            error_log("[AliExpressApiClient] getFeedItemIds falhou: " . $e->getMessage());
            return [
                'total'     => 0,
                'products'  => [],
                'search_id' => '',
                'raw'       => [],
            ];
        }
    }

    /**
     * Consulta os nomes de feeds de recomendação e bestsellers disponíveis no AliExpress.
     * Endpoint oficial: aliexpress.ds.feedname.get (dropshiper.pdf).
     *
     * @return array<int, string> Lista de nomes de feeds oficiais disponíveis
     */
    public function getFeedNames(): array
    {
        try {
            $response = $this->execute('aliexpress.ds.feedname.get', [], $this->accessToken);
            $this->lastError = null;
            $unwrapped = \DomainSystem\Plugins\domain_drop\ValueObjects\AliExpressToken::unwrapPayload($response);
            $result = $unwrapped['result'] ?? ($response['result'] ?? $unwrapped);
            $feeds = $result['prompts'] ?? ($result['feed_names'] ?? ($result['feeds'] ?? []));
            if (is_array($feeds) && !empty($feeds)) {
                return array_values(array_filter(array_map('strval', $feeds)));
            }
        } catch (Throwable $e) {
            $this->lastError = $e->getMessage();
        }

        return ['DS bestseller', 'Top Ranking', 'Hot Products'];
    }

    public function searchProducts(array $filters = []): array
    {
        $hasTextQuery = !empty($filters['query']) || !empty($filters['keyword']) || !empty($filters['keyWord']) || !empty($filters['keywords']) || !empty($filters['search']);
        $hasCategoryId = !empty($filters['category_id']) || !empty($filters['categoryId']) || !empty($filters['cate_id']);

        if ($hasTextQuery || $hasCategoryId) {
            $textRes = $this->textSearch($filters);
            $unwrapped = \DomainSystem\Plugins\domain_drop\ValueObjects\AliExpressToken::unwrapPayload($textRes);
            $data = $unwrapped['data'] ?? ($textRes['data'] ?? ($unwrapped['result'] ?? ($textRes['result'] ?? [])));
            $rawProducts = $data['products'] ?? ($unwrapped['products'] ?? []);
            if (isset($rawProducts['traffic_product_d_t_o'])) {
                $products = $rawProducts['traffic_product_d_t_o'];
            } elseif (isset($rawProducts['product'])) {
                $products = $rawProducts['product'];
            } else {
                $products = $rawProducts;
            }

            if (is_array($products) && !empty($products)) {
                $maxEnrich = !empty($filters['enrich_details']) ? (int)($filters['enrich_limit'] ?? 5) : 0;
                $enrichedProducts = [];
                $enrichedCount = 0;
                foreach ($products as $p) {
                    $pId = (string)($p['itemId'] ?? ($p['item_id'] ?? ($p['product_id'] ?? ($p['productId'] ?? ''))));
                    if ($maxEnrich > 0 && $enrichedCount < $maxEnrich && $pId !== '' && is_numeric($pId)) {
                        try {
                            $details = $this->getProductDetails($pId, 'pt', 'BRL');
                            $unwrappedDetails = \DomainSystem\Plugins\domain_drop\ValueObjects\AliExpressToken::unwrapPayload($details);
                            $productData = $unwrappedDetails['result'] ?? ($details['result'] ?? $unwrappedDetails);
                            if (!empty($productData) && is_array($productData) && (isset($productData['ae_item_base_info_dto']) || isset($productData['ae_multimedia_info_dto']))) {
                                $merged = array_merge($p, $productData);
                                if (!isset($merged['itemUrl']) && !empty($p['itemUrl'])) {
                                    $merged['itemUrl'] = $p['itemUrl'];
                                }
                                if (!isset($merged['itemId'])) {
                                    $merged['itemId'] = $pId;
                                }
                                $enrichedProducts[] = $merged;
                                $enrichedCount++;
                                continue;
                            }
                        } catch (Throwable $e) {
                            // Se falhar a consulta de detalhes individuais, preserva o card de busca
                        }
                    }
                    $enrichedProducts[] = $p;
                }
                return $enrichedProducts;
            }
        }

        // Bestseller feed query oficial aliexpress.ds.feed.itemids.get (dropshiper.pdf)
        $catId = $filters['category_id'] ?? ($filters['categoryId'] ?? ($filters['cate_id'] ?? null));
        $feedName = (string)($filters['feed_name'] ?? 'DS bestseller');
        $pageSize = (int)($filters['page_size'] ?? ($filters['pageSize'] ?? 20));

        $feedRes = $this->getFeedItemIds($feedName, $catId ? (string)$catId : null, $pageSize);
        if (!empty($feedRes['products']) && is_array($feedRes['products'])) {
            $feedProducts = [];
            foreach (array_slice($feedRes['products'], 0, $pageSize) as $pId) {
                try {
                    $details = $this->getProductDetails((string)$pId, 'pt', 'BRL');
                    $unwrappedDetails = \DomainSystem\Plugins\domain_drop\ValueObjects\AliExpressToken::unwrapPayload($details);
                    $productData = $unwrappedDetails['result'] ?? ($details['result'] ?? $unwrappedDetails);
                    if (!empty($productData) && is_array($productData)) {
                        $feedProducts[] = $productData;
                    }
                } catch (Throwable $e) {
                    // Isolamento gracioso
                }
            }
            if (!empty($feedProducts)) {
                return $feedProducts;
            }
        }

        return [];
    }

    public function queryTrackingInfo(
        string $logisticsNo,
        string $origin = 'ESCROW',
        string $outRef = '',
        string $serviceName = 'CAINIAO',
        string $toArea = 'BR'
    ): array {
        $logisticsNo = trim($logisticsNo);
        if ($logisticsNo === '' && trim($outRef) === '') {
            return [];
        }

        $params = [
            'logistics_no' => $logisticsNo,
            'origin'       => $origin !== '' ? $origin : 'ESCROW',
            'out_ref'      => trim($outRef),
            'service_name' => $serviceName !== '' ? $serviceName : 'CAINIAO',
            'to_area'      => $toArea !== '' ? strtoupper($toArea) : 'BR',
        ];

        $response = $this->execute('aliexpress.logistics.ds.trackinginfo.query', $params, $this->accessToken);

        $details = $response['result']['details']['details']
            ?? ($response['result']['details'] ?? null)
            ?? ($response['aliexpress_logistics_ds_trackinginfo_query_response']['details']['details'] ?? null)
            ?? ($response['aliexpress_logistics_ds_trackinginfo_query_response']['result']['details']['details'] ?? null)
            ?? ($response['aliexpress_logistics_ds_trackinginfo_query_response']['result']['details'] ?? []);

        return [
            'official_website' => (string)($response['result']['official_website'] ?? $response['aliexpress_logistics_ds_trackinginfo_query_response']['official_website'] ?? ''),
            'details'          => is_array($details) ? $details : [],
            'raw'              => $response,
        ];
    }

    public function getOfficialCategories(int|string $categoryId = 0, string $language = 'pt', bool $forceRefresh = false): array
    {
        $langKey = strtolower(trim($language)) ?: 'pt';
        $cacheFile = dirname(__DIR__, 4) . '/storage/cache/aliexpress_categories_' . $langKey . '.json';

        if (!$forceRefresh && file_exists($cacheFile)) {
            $mtime = filemtime($cacheFile);
            // Cache oficial de 7 dias (categorias de e-commerce global são altamente estáveis)
            if ((time() - $mtime) < 604800) {
                $cached = json_decode((string)file_get_contents($cacheFile), true);
                if (is_array($cached) && !empty($cached)) {
                    return $cached;
                }
            }
        }

        try {
            $response = $this->execute('aliexpress.ds.category.get', [
                'category_id' => (string)$categoryId,
                'language'    => $langKey,
            ]);

            $categories = $response['resp_result']['result']['categories']
                ?? ($response['result']['categories']
                ?? ($response['aliexpress_ds_category_get_response']['resp_result']['result']['categories'] ?? []));

            if (is_array($categories) && !empty($categories)) {
                $dir = dirname($cacheFile);
                if (!is_dir($dir)) {
                    mkdir($dir, 0777, true);
                }
                file_put_contents($cacheFile, json_encode($categories, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
                return $categories;
            }
        } catch (Throwable $e) {
            // Em caso de instabilidade na conexão, utiliza cache em disco se existir
            if (file_exists($cacheFile)) {
                $cached = json_decode((string)file_get_contents($cacheFile), true);
                if (is_array($cached) && !empty($cached)) {
                    return $cached;
                }
            }
        }

        return [];
    }

    public function getSkuAttributes(int|string $categoryId): array
    {
        $params = [
            'query_sku_attribute_info_request' => json_encode([
                'aliexpress_category_id' => (string)$categoryId,
            ], JSON_UNESCAPED_SLASHES),
        ];

        try {
            $response = $this->execute('aliexpress.solution.sku.attribute.query', $params, $this->accessToken);
            $this->lastError = null;
            $unwrapped = \DomainSystem\Plugins\domain_drop\ValueObjects\AliExpressToken::unwrapPayload($response);
            $res = $unwrapped['result'] ?? ($unwrapped['data'] ?? $unwrapped);
            return is_array($res) ? $res : [];
        } catch (Throwable $e) {
            $this->lastError = $e->getMessage();
            error_log("[AliExpressApiClient] getSkuAttributes falhou: " . $e->getMessage());
            return [];
        }
    }

    public function getProductEanCode(string $eanCode): array
    {
        $code = trim($eanCode);
        if ($code === '') {
            return [];
        }

        try {
            $response = $this->execute('aliexpress.product.eancode.info.query', ['ean_code' => $code], $this->accessToken);
            $this->lastError = null;
            $unwrapped = \DomainSystem\Plugins\domain_drop\ValueObjects\AliExpressToken::unwrapPayload($response);
            $res = $unwrapped['result'] ?? ($unwrapped['data'] ?? $unwrapped);
            return is_array($res) ? $res : [];
        } catch (Throwable $e) {
            $this->lastError = $e->getMessage();
            error_log("[AliExpressApiClient] getProductEanCode falhou: " . $e->getMessage());
            return [];
        }
    }

    public function queryFreight(array $deliveryReq): array
    {
        try {
            $formattedReq = [
                'productId'     => (string)($deliveryReq['productId'] ?? ($deliveryReq['product_id'] ?? '')),
                'shipToCountry' => (string)($deliveryReq['shipToCountry'] ?? ($deliveryReq['ship_to_country'] ?? 'BR')),
                'quantity'      => (int)($deliveryReq['quantity'] ?? 1),
                'language'      => (string)($deliveryReq['language'] ?? 'pt_BR'),
                'currency'      => (string)($deliveryReq['currency'] ?? 'BRL'),
                'locale'        => (string)($deliveryReq['locale'] ?? 'pt_BR'),
            ];
            if (!empty($deliveryReq['selectedSkuId'])) {
                $formattedReq['selectedSkuId'] = (string)$deliveryReq['selectedSkuId'];
            } elseif (!empty($deliveryReq['sku_id'])) {
                $formattedReq['selectedSkuId'] = (string)$deliveryReq['sku_id'];
            }

            $response = $this->execute('aliexpress.ds.freight.query', [
                'queryDeliveryReq' => json_encode($formattedReq, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE),
            ], $this->accessToken);
            $this->lastError = null;
            $unwrapped = \DomainSystem\Plugins\domain_drop\ValueObjects\AliExpressToken::unwrapPayload($response);
            $res = $unwrapped['result'] ?? ($unwrapped['data'] ?? $unwrapped);
            return is_array($res) ? $res : [];
        } catch (Throwable $e) {
            $this->lastError = $e->getMessage();
            error_log("[AliExpressApiClient] queryFreight falhou: " . $e->getMessage());
            return [];
        }
    }

    public function queryProductInventory(int|string $productId): array
    {
        try {
            $response = $this->execute('aliexpress.solution.product.inventory.query', ['product_id' => (string)$productId], $this->accessToken);
            $this->lastError = null;
            $unwrapped = \DomainSystem\Plugins\domain_drop\ValueObjects\AliExpressToken::unwrapPayload($response);
            $res = $unwrapped['result'] ?? ($unwrapped['data'] ?? $unwrapped);
            return is_array($res) ? $res : [];
        } catch (Throwable $e) {
            $this->lastError = $e->getMessage();
            error_log("[AliExpressApiClient] queryProductInventory falhou: " . $e->getMessage());
            return [];
        }
    }

    public function updateBatchProductPrices(array $priceUpdates): array
    {
        if (empty($priceUpdates)) {
            return [];
        }

        try {
            $response = $this->execute('aliexpress.solution.batch.product.price.update', [
                'mutiple_product_update_list' => json_encode($priceUpdates, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE),
            ], $this->accessToken);
            $this->lastError = null;
            return \DomainSystem\Plugins\domain_drop\ValueObjects\AliExpressToken::unwrapPayload($response);
        } catch (Throwable $e) {
            $this->lastError = $e->getMessage();
            error_log("[AliExpressApiClient] updateBatchProductPrices falhou: " . $e->getMessage());
            return [];
        }
    }

    /**
     * Algoritmo Oficial de Assinatura IOP da AliExpress Open Platform.
     * 1. Ordena parâmetros alfabeticamente por chave (ksort).
     * 2. Concatena chave e valor em string corrida.
     * 3. Calcula HMAC-SHA256 em maiúsculas usando o AppSecret.
     * 
     * @param array<string, mixed> $params
     */
    public function generateSignature(string $apiMethod, array $params): string
    {
        ksort($params);

        $stringToBeSigned = '';
        if (str_contains($apiMethod, '/')) {
            $stringToBeSigned .= $apiMethod;
        }

        foreach ($params as $k => $v) {
            if ($v !== null && $v !== '') {
                $stringToBeSigned .= "$k$v";
            }
        }

        return strtoupper(hash_hmac('sha256', $stringToBeSigned, $this->appSecret));
    }

    /**
     * Retorna o timestamp em milissegundos exigido pela AliExpress API.
     */
    private function getMillisecondTimestamp(): string
    {
        return (string)(int)(microtime(true) * 1000);
    }

    /**
     * Executa requisição HTTP segura via cURL com POST.
     * 
     * @param array<string, mixed> $postData
     * @return array<string, mixed>
     */
    private function sendHttpRequest(string $url, array $postData = []): array
    {
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($postData));
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_TIMEOUT, $this->timeout);
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 5);
        curl_setopt($ch, CURLOPT_USERAGENT, $this->sdkVersion);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 2);

        $rawResponse = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $error = curl_error($ch);
        curl_close($ch);

        (new ApiUsageTracker())->recordRequest();

        if ($rawResponse === false) {
            throw new AliExpressApiException("[AliExpressApiClient] Falha na conexão com o gateway do AliExpress: {$error}", 0, 'CONNECTION_ERROR');
        }

        // 1. Validar Status HTTP primeiro (HTTP 2xx é sucesso HTTP)
        if ($httpCode < 200 || $httpCode >= 300) {
            $decodedErr = json_decode((string)$rawResponse, true);
            if (is_array($decodedErr)) {
                $errCode = (string)($decodedErr['code'] ?? ($decodedErr['error_response']['code'] ?? "HTTP_{$httpCode}"));
                $errMsg = (string)($decodedErr['message'] ?? ($decodedErr['error_response']['msg'] ?? 'Falha de resposta HTTP do gateway AliExpress.'));
                throw new AliExpressApiException("[AliExpress Gateway HTTP {$httpCode} - {$errCode}] {$errMsg}", $httpCode, $errCode);
            }
            throw new AliExpressApiException(
                "[AliExpress Gateway HTTP {$httpCode}] Falha de resposta HTTP do gateway AliExpress.",
                $httpCode,
                'HTTP_ERROR'
            );
        }

        // 2. Decodificar resposta JSON
        $decoded = json_decode((string)$rawResponse, true);

        if (!is_array($decoded)) {
            // Se vier XML ou formato inesperado
            return [
                'raw_response' => (string)$rawResponse,
                'http_code'    => $httpCode,
            ];
        }

        // 3. Se o AliExpress retornar erro formal na resposta (formato TOP error_response ou IOP code)
        if (isset($decoded['error_response']) && is_array($decoded['error_response'])) {
            $err = $decoded['error_response'];
            $errCode = (string)($err['sub_code'] ?? ($err['code'] ?? 'API_ERROR'));
            $msg = (string)($err['sub_msg'] ?? ($err['msg'] ?? 'Erro desconhecido da AliExpress API'));
            throw new AliExpressApiException("[AliExpress Gateway Error: {$errCode}] {$msg}", 0, $errCode);
        }

        if (isset($decoded['code']) && (string)$decoded['code'] !== '0' && (string)$decoded['code'] !== '200') {
            $codeStr = (string)$decoded['code'];
            $msg = (string)($decoded['message'] ?? ($decoded['msg'] ?? ($decoded['sub_msg'] ?? 'Erro retornado pela AliExpress API')));
            $subCode = (string)($decoded['sub_code'] ?? $codeStr);
            throw new AliExpressApiException("[AliExpress Gateway Error: {$codeStr}] {$msg}", 0, $subCode);
        }

        return $decoded;
    }
}
