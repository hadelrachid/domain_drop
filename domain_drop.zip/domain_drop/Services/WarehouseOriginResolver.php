<?php

declare(strict_types=1);

namespace DomainSystem\Plugins\domain_drop\Services;

use DomainSystem\Plugins\domain_drop\Contracts\WarehouseOriginResolverInterface;

/**
 * Resolvedor e Classificador de Procedência Logística e Entrepostos (SRP / DIP).
 * 
 * Atende às diretrizes das auditorias técnicas:
 * - Elimina a confusão entre país cadastral da loja (store_country_code) e país físico do estoque.
 * - Detecta as tags oficiais de Local Supply da Alibaba (ex: 'local_flag' em sellingPoints e log_point).
 * - Suporta 3 estados oficiais: BR, CN e UNKNOWN (sem converter ausência de dados em China).
 */
class WarehouseOriginResolver implements WarehouseOriginResolverInterface
{
    public function resolve(array $rawItem, ?string $title = null): string
    {
        // 0. Informação oficial do endpoint de frete (aliexpress.ds.freight.query - Pág. 229-230)
        $freightVal = $rawItem['freight']['ship_from_country']
            ?? ($rawItem['freight_info']['ship_from_country']
            ?? ($rawItem['delivery_info']['ship_from_country']
            ?? ($rawItem['ship_from_country'] ?? '')));
        $freightShipFrom = is_scalar($freightVal) ? strtoupper(trim((string)$freightVal)) : '';
        if ($freightShipFrom === 'BR') {
            return self::ORIGIN_BR;
        }
        if ($freightShipFrom === 'CN') {
            return self::ORIGIN_CN;
        }
        if ($freightShipFrom !== '' && strlen($freightShipFrom) === 2) {
            return $freightShipFrom;
        }

        // 1. Tags explícitas de armazém previamente auditadas
        if (!empty($rawItem['origem_brasil']) || !empty($rawItem['entreposto_brasil'])) {
            return self::ORIGIN_BR;
        }

        // 2. Campo de expedição física (ship_from / send_goods_country_code / delivery.shippingFrom / ship_from_country)
        $shipVal = $rawItem['ship_from']
            ?? ($rawItem['send_goods_country_code']
            ?? ($rawItem['delivery']['shippingFrom']
            ?? ($rawItem['ship_from_country'] ?? '')));
        $shipFrom = is_scalar($shipVal) ? strtoupper(trim((string)$shipVal)) : '';

        if (in_array($shipFrom, ['BR', 'BRAZIL', 'BRASIL'], true)) {
            return self::ORIGIN_BR;
        }

        // 3. Inspeção de tags oficiais do AliExpress (Local Supply / ASF / local_flag)
        if (!empty($rawItem['sellingPoints']) && is_array($rawItem['sellingPoints'])) {
            foreach ($rawItem['sellingPoints'] as $sp) {
                if (!is_array($sp)) {
                    continue;
                }
                $source = strtolower(trim((string)($sp['source'] ?? '')));
                $tagId = strtolower(trim((string)($sp['sellingPointTagId'] ?? '')));
                if ($source === 'local_flag' || $tagId === 'local_flag') {
                    return self::ORIGIN_BR;
                }
            }
        }

        // 4. Verificação de log_point de rastreio de interface
        $logPoint = is_array($rawItem['log_point'] ?? null)
            ? (string)json_encode($rawItem['log_point'])
            : (string)($rawItem['log_point'] ?? '');
        if ($logPoint !== '' && str_contains($logPoint, 'local_flag')) {
            return self::ORIGIN_BR;
        }

        // 5. Verificação de tagList estruturada
        if (!empty($rawItem['tagList']) && is_array($rawItem['tagList'])) {
            foreach ($rawItem['tagList'] as $t) {
                $tagStr = is_string($t) ? $t : (string)($t['tag'] ?? '');
                if (stripos($tagStr, 'LOCAL_DELIVERY') !== false 
                    || stripos($tagStr, 'DESPACHO_BRASIL') !== false
                    || stripos($tagStr, 'ENTREGA_LOCAL_BR') !== false
                ) {
                    return self::ORIGIN_BR;
                }
            }
        }

        // 6. Confirmação de Entreposto Central China (Cross-Border)
        if (in_array($shipFrom, ['CN', 'CHINA'], true) 
            || !empty($rawItem['origem_china']) 
            || !empty($rawItem['remessa_conforme'])
            || stripos($logPoint, 'cross_border') !== false
            || stripos($logPoint, 'choice') !== false
        ) {
            return self::ORIGIN_CN;
        }

        // 8. Se a expedição for de outro país documentado (ex: US, ES, FR)
        if ($shipFrom !== '' && strlen($shipFrom) === 2 && $shipFrom !== 'BR' && $shipFrom !== 'CN') {
            return $shipFrom;
        }

        return self::ORIGIN_UNKNOWN;
    }

    public function isShippedFromBrazil(array $rawItem, ?string $title = null): bool
    {
        return $this->resolve($rawItem, $title) === self::ORIGIN_BR;
    }
}
