<?php
/**
 * Palco Dinâmico de Produtos da Vitrine (/loja)
 *
 * @var array<int, \DomainSystem\Plugins\domain_drop\DTO\DropshipProductDto> $products
 * @var int $totalCount
 * @var string $selectedCategory
 * @var string $search
 * @var string $baseUrl
 */
?>
<!-- Informações e Contagem de Produtos do Palco -->
<div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px; font-size: 13px; color: #94a3b8; flex-wrap: wrap; gap: 8px;">
    <div>
        Exibindo <strong style="color: #5cd67d; font-size: 15px;"><?= empty($products) ? 0 : (($page - 1) * 48 + 1) ?>-<?= min(($page - 1) * 48 + count($products), $totalCount) ?></strong> de <strong style="color: #fff;"><?= $totalCount ?></strong> produtos
        <?php if (isset($totalPages) && $totalPages > 1): ?>
            <span style="color: #45f3ff; margin-left: 6px;">(Página <?= $page ?> de <?= $totalPages ?>)</span>
        <?php endif; ?>
        <?php if (!empty($selectedCategory)): ?>
            na categoria <span style="color: #F0D060; font-weight: 700;">"<?= htmlspecialchars($selectedCategory) ?>"</span>
        <?php endif; ?>
        <?php if (!empty($search)): ?>
            para a busca <span style="color: #60a5fa; font-weight: 700;">"<?= htmlspecialchars($search) ?>"</span>
        <?php endif; ?>
    </div>
    <?php if (!empty($selectedCategory) || !empty($search) || !empty($_GET['sort'])): ?>
        <a href="<?= $baseUrl ?>/loja" onclick="event.preventDefault(); filterCatalogDynamically(this.href);" style="color: #f87171; text-decoration: none; font-size: 12px; font-weight: 600;">✕ Limpar Filtros</a>
    <?php endif; ?>
</div>

<!-- Grade de Produtos Dinâmica -->
<?php if (empty($products)): ?>
    <div style="background: rgba(255,255,255,0.02); border: 1px dashed rgba(255,255,255,0.12); border-radius: 12px; padding: 50px 20px; text-align: center; animation: fadeInStage 0.25s ease;">
        <div style="font-size: 40px; margin-bottom: 12px;">🛍️</div>
        <h3 style="color: #fff; font-size: 19px; margin: 0 0 8px 0;">Nenhum produto encontrado</h3>
        <p style="color: #94a3b8; font-size: 14px; margin: 0 0 20px 0;">
            Tente selecionar outra categoria ou limpar a pesquisa para ver mais produtos.
        </p>
        <a href="<?= $baseUrl ?>/loja" onclick="event.preventDefault(); filterCatalogDynamically(this.href);" class="gold-button" style="padding: 10px 24px; font-size: 13px;">
            Ver Todos os Produtos
        </a>
    </div>
<?php else: ?>
    <div class="store-grid" style="animation: fadeInStage 0.25s ease;">
        <?php foreach ($products as $p): ?>
            <?php
            $productUrl = !empty($p->slug) ? $baseUrl . '/produto/' . urlencode($p->slug) : $baseUrl . '/produto/' . (int)$p->id;
            $checkoutUrl = $baseUrl . '/checkout/produto/' . (int)$p->id;
            $refPrice = $p->salePriceBrl * 1.35;
            ?>
            <article class="store-card">
                <!-- Image Box -->
                <div class="store-card-img-box" style="position: relative; width: 100%; height: 230px; background: #0c0f12; overflow: hidden;">
                    <a href="<?= htmlspecialchars($productUrl) ?>">
                        <?php if (!empty($p->mainImageUrl)): ?>
                            <img src="<?= htmlspecialchars($p->mainImageUrl) ?>" alt="<?= htmlspecialchars($p->title) ?>" onerror="this.onerror=null; this.src='https://images.unsplash.com/photo-1526738549149-8e07eca6c147?w=600&auto=format&fit=crop&q=80';" loading="lazy" style="width: 100%; height: 100%; object-fit: cover; transition: transform 0.3s ease;" onmouseover="this.style.transform='scale(1.06)'" onmouseout="this.style.transform='scale(1)'">
                        <?php else: ?>
                            <div style="width: 100%; height: 100%; display: flex; align-items: center; justify-content: center; color: #94a3b8; font-size: 36px;">📦</div>
                        <?php endif; ?>
                    </a>

                    <?php if (!empty($p->category)): ?>
                        <span style="position: absolute; top: 10px; left: 10px; background: rgba(0,0,0,0.75); backdrop-filter: blur(4px); color: #fff; padding: 3px 8px; border-radius: 5px; font-size: 10px; font-weight: 700; border: none;">
                            <?= htmlspecialchars($p->category) ?>
                        </span>
                    <?php endif; ?>

                    <?php if ($p->rating > 0): ?>
                        <?php
                        $pStarsCount = (int)max(1, min(5, round((float)$p->rating)));
                        $pStarsEmoji = str_repeat('⭐', $pStarsCount);
                        ?>
                        <span style="position: absolute; bottom: 10px; left: 10px; background: rgba(0,0,0,0.85); border: 1px solid rgba(251,191,36,0.3); color: #fbbf24; padding: 3px 8px; border-radius: 6px; font-size: 11px; font-weight: 700; display: inline-flex; align-items: center; gap: 4px; backdrop-filter: blur(4px);">
                            <span><?= $pStarsEmoji ?></span>
                            <span style="color: #fff; font-family: monospace;"><?= number_format($p->rating, 1) ?></span>
                        </span>
                    <?php endif; ?>

                    <span style="position: absolute; top: 10px; right: 10px; background: linear-gradient(135deg, #F0D060 0%, #D4AF37 100%); color: #0b0f17; padding: 3px 7px; border-radius: 4px; font-size: 10px; font-weight: 800; letter-spacing: 0.5px;">
                        PROMO
                    </span>
                </div>

                <!-- Details -->
                <div class="store-card-body" style="padding: 16px; flex: 1; display: flex; flex-direction: column; justify-content: space-between;">
                    <div>
                        <h3 style="margin: 0 0 8px 0; font-size: 14px; font-weight: 600; line-height: 1.4; max-height: 2.8em; overflow: hidden; display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical;">
                            <a href="<?= htmlspecialchars($productUrl) ?>" style="color: #fff; text-decoration: none;" title="<?= htmlspecialchars($p->title) ?>">
                                <?= htmlspecialchars($p->title) ?>
                            </a>
                        </h3>

                        <?php
                        $cardRating = (float)($p->rating ?? 4.8);
                        $starCount = (int)max(1, min(5, round($cardRating > 0 ? $cardRating : 4.8)));
                        $starsEmoji = str_repeat('⭐', $starCount);
                        $ordersCount = (int)($p->ordersCount ?? 0);
                        $salesInformed = (string)($p->attributes['Vendas_Informadas'] ?? '');
                        $reviewsCount = (int)($p->attributes['reviews_count'] ?? 0);
                        ?>
                        <div style="display: flex; align-items: center; gap: 6px; flex-wrap: wrap; margin-bottom: 10px; font-size: 11.5px;">
                            <span style="letter-spacing: 1px; font-size: 12px;"><?= $starsEmoji ?></span>
                            <strong style="color: #fbbf24; font-family: monospace; font-size: 12px;"><?= number_format($cardRating > 0 ? $cardRating : 4.8, 1) ?></strong>
                            <?php if ($ordersCount > 0 && $salesInformed !== 'nao'): ?>
                                <span style="color: #94a3b8; font-size: 11px;">• <strong style="color: #e2e8f0;"><?= number_format($ordersCount, 0, ',', '.') ?></strong> vendidos</span>
                            <?php elseif ($reviewsCount > 0): ?>
                                <span style="color: #94a3b8; font-size: 11px;">• <strong style="color: #e2e8f0;"><?= $reviewsCount ?></strong> avaliações</span>
                            <?php else: ?>
                                <span style="color: #94a3b8; font-size: 11px;">• <strong style="color: #e2e8f0;">Destaque</strong> em vendas</span>
                            <?php endif; ?>
                        </div>

                        <?php $isNational = (!empty($p->attributes['origem_brasil']) || (isset($p->attributes['ship_from']) && $p->attributes['ship_from'] === 'BR')); ?>
                        <div style="margin-bottom: 14px;">
                            <div style="font-size: 11px; color: #94a3b8; text-decoration: line-through;">
                                R$ <?= number_format($refPrice, 2, ',', '.') ?>
                            </div>
                            <div class="store-card-price" style="font-size: 20px; font-weight: 700; color: #5cd67d; font-family: monospace;">
                                R$ <?= number_format($p->salePriceBrl, 2, ',', '.') ?>
                            </div>
                            <div style="font-size: 10px; color: <?= $isNational ? '#4ade80' : '#94a3b8' ?>; margin-top: 2px; font-weight: <?= $isNational ? '600' : 'normal' ?>; display: flex; align-items: center; flex-wrap: wrap;">
                                <?= $isNational ? (\DomainSystem\Plugins\domain_drop\Helpers\FlagHelper::br(15, 10) . ' Estoque no Brasil • Envio 3 a 7 dias') : 'em até 12x ou Pix com desconto' ?>
                            </div>
                        </div>
                    </div>

                    <!-- Action Buttons: Ver Detalhes e Comprar Explícitos -->
                    <?php
                    $jsProdId = htmlspecialchars((string)json_encode((string)($p->aliexpressId ?: (string)$p->id)), ENT_QUOTES, 'UTF-8');
                    $jsProdTitle = htmlspecialchars((string)json_encode((string)$p->title), ENT_QUOTES, 'UTF-8');
                    $jsProdCat = htmlspecialchars((string)json_encode((string)$p->category), ENT_QUOTES, 'UTF-8');
                    ?>
                    <div class="store-card-actions" style="display: flex; gap: 6px;">
                        <a href="<?= htmlspecialchars($productUrl) ?>" onclick="if(window.trackDropAction) window.trackDropAction(<?= $jsProdId ?>, <?= $jsProdTitle ?>, <?= $jsProdCat ?>, 'view_details');" style="flex: 1; background: rgba(255,255,255,0.06); border: 1.5px solid rgba(212,175,55,0.4); color: #F0D060; text-decoration: none; padding: 0 6px; height: 36px; border-radius: 6px; font-size: 11.5px; font-weight: 700; display: inline-flex; align-items: center; justify-content: center; gap: 4px; transition: all 0.2s ease; box-sizing: border-box; white-space: nowrap; line-height: 1.2;" onmouseover="this.style.background='rgba(212,175,55,0.18)'; this.style.borderColor='#F0D060';" onmouseout="this.style.background='rgba(255,255,255,0.06)'; this.style.borderColor='rgba(212,175,55,0.4)';">
                            <span>🔍</span>
                            <span>Ver Detalhes</span>
                        </a>
                        <a href="<?= htmlspecialchars($checkoutUrl) ?>" onclick="return handleStageBuyClick(event, this, <?= (int)$p->id ?>, <?= htmlspecialchars((string)json_encode((string)$p->slug), ENT_QUOTES, 'UTF-8') ?>, <?= htmlspecialchars((string)json_encode($checkoutUrl), ENT_QUOTES, 'UTF-8') ?>, <?= $jsProdId ?>, <?= $jsProdTitle ?>, <?= $jsProdCat ?>);" style="flex: 1; background: linear-gradient(135deg, #F0D060 0%, #D4AF37 100%); color: #0b0f17; text-decoration: none; padding: 0 6px; height: 36px; border-radius: 6px; font-size: 11.5px; font-weight: 800; text-align: center; text-transform: uppercase; letter-spacing: 0.4px; box-shadow: 0 4px 14px rgba(212, 175, 55, 0.35); transition: all 0.2s ease; display: inline-flex; align-items: center; justify-content: center; box-sizing: border-box; white-space: nowrap; line-height: 1.2;">
                            Comprar ➔
                        </a>
                    </div>
                </div>
            </article>
        <?php endforeach; ?>
    </div>

    <!-- Paginação SEO da Vitrine Pública (48 itens por página) -->
    <?php if (isset($totalPages) && $totalPages > 1): ?>
        <?php
        $frontQuery = $_GET;
        unset($frontQuery['page'], $frontQuery['ajax']);
        $stageRoute = isset($pageBaseRoute) && $pageBaseRoute !== '' ? (string)$pageBaseRoute : '/loja';
        $buildFrontPageUrl = function(int $p) use ($baseUrl, $frontQuery, $stageRoute): string {
            $params = array_merge($frontQuery, ['page' => $p]);
            return $baseUrl . $stageRoute . '?' . http_build_query($params);
        };
        ?>
        <nav aria-label="Navegação da Loja" style="display: flex; justify-content: space-between; align-items: center; background: rgba(255,255,255,0.03); border: 1px solid rgba(255,255,255,0.08); border-radius: 10px; padding: 14px 20px; margin-top: 32px; margin-bottom: 24px; flex-wrap: wrap; gap: 12px;">
            <div style="font-size: 13px; color: #94a3b8;">
                Página <strong style="color: #fff;"><?= $page ?></strong> de <strong style="color: #fff;"><?= $totalPages ?></strong> &bull; Total: <strong style="color: #F0D060;"><?= $totalCount ?></strong> produtos
            </div>
            
            <div style="display: flex; align-items: center; gap: 6px; flex-wrap: wrap;">
                <?php if ($page > 1): ?>
                    <a href="<?= htmlspecialchars($buildFrontPageUrl(1)) ?>" onclick="event.preventDefault(); filterCatalogDynamically(this.href);" style="background: rgba(255,255,255,0.06); border: 1px solid rgba(255,255,255,0.15); color: #fff; padding: 7px 12px; border-radius: 6px; font-size: 12px; text-decoration: none; font-weight: 600;" title="Primeira Página">
                        &laquo; Primeira
                    </a>
                    <a href="<?= htmlspecialchars($buildFrontPageUrl($page - 1)) ?>" onclick="event.preventDefault(); filterCatalogDynamically(this.href);" style="background: rgba(255,255,255,0.06); border: 1px solid rgba(255,255,255,0.15); color: #fff; padding: 7px 12px; border-radius: 6px; font-size: 12px; text-decoration: none; font-weight: 600;">
                        &lsaquo; Anterior
                    </a>
                <?php else: ?>
                    <span style="background: rgba(255,255,255,0.02); border: 1px solid rgba(255,255,255,0.06); color: #555; padding: 7px 12px; border-radius: 6px; font-size: 12px; cursor: not-allowed;">
                        &lsaquo; Anterior
                    </span>
                <?php endif; ?>

                <?php
                $frontStartP = max(1, $page - 3);
                $frontEndP = min($totalPages, $page + 3);
                if ($frontStartP > 1) {
                    echo '<span style="color: #666; padding: 0 4px;">...</span>';
                }
                for ($p = $frontStartP; $p <= $frontEndP; $p++):
                ?>
                    <?php if ($p === $page): ?>
                        <span style="background: linear-gradient(135deg, #F0D060 0%, #D4AF37 100%); color: #0b0f17; padding: 7px 14px; border-radius: 6px; font-size: 12px; font-weight: 800; box-shadow: 0 2px 10px rgba(212,175,55,0.35);">
                            <?= $p ?>
                        </span>
                    <?php else: ?>
                        <a href="<?= htmlspecialchars($buildFrontPageUrl($p)) ?>" onclick="event.preventDefault(); filterCatalogDynamically(this.href);" style="background: rgba(255,255,255,0.06); border: 1px solid rgba(255,255,255,0.15); color: #fff; padding: 7px 12px; border-radius: 6px; font-size: 12px; text-decoration: none; font-weight: 600;">
                            <?= $p ?>
                        </a>
                    <?php endif; ?>
                <?php endfor; ?>
                <?php if ($frontEndP < $totalPages): ?>
                    <span style="color: #666; padding: 0 4px;">...</span>
                <?php endif; ?>

                <?php if ($page < $totalPages): ?>
                    <a href="<?= htmlspecialchars($buildFrontPageUrl($page + 1)) ?>" onclick="event.preventDefault(); filterCatalogDynamically(this.href);" style="background: rgba(255,255,255,0.06); border: 1px solid rgba(255,255,255,0.15); color: #fff; padding: 7px 12px; border-radius: 6px; font-size: 12px; text-decoration: none; font-weight: 600;">
                        Próxima &rsaquo;
                    </a>
                    <a href="<?= htmlspecialchars($buildFrontPageUrl($totalPages)) ?>" onclick="event.preventDefault(); filterCatalogDynamically(this.href);" style="background: rgba(255,255,255,0.06); border: 1px solid rgba(255,255,255,0.15); color: #fff; padding: 7px 12px; border-radius: 6px; font-size: 12px; text-decoration: none; font-weight: 600;" title="Última Página">
                        Última &raquo;
                    </a>
                <?php else: ?>
                    <span style="background: rgba(255,255,255,0.02); border: 1px solid rgba(255,255,255,0.06); color: #555; padding: 7px 12px; border-radius: 6px; font-size: 12px; cursor: not-allowed;">
                        Próxima &rsaquo;
                    </span>
                <?php endif; ?>
            </div>
        </nav>
    <?php endif; ?>
<?php endif; ?>

<style>
@keyframes dropToastSlideIn {
    from { transform: translateX(110%); opacity: 0; }
    to { transform: translateX(0); opacity: 1; }
}
</style>

<script>
if (typeof showDropToast !== 'function') {
    function showDropToast(options) {
        var title = options.title || 'Aviso';
        var message = options.message || '';
        var type = options.type || 'warning';
        var duration = options.duration || 7000;

        var container = document.getElementById('domain-drop-toast-container');
        if (!container) {
            container = document.createElement('div');
            container.id = 'domain-drop-toast-container';
            container.style.cssText = 'position: fixed; top: 24px; right: 24px; z-index: 9999999; display: flex; flex-direction: column; gap: 12px; pointer-events: none; max-width: 440px; width: calc(100vw - 32px);';
            document.body.appendChild(container);
        }

        var toast = document.createElement('div');
        var isAlert = type === 'error' || type === 'warning';
        var borderColor = isAlert ? '#ef4444' : '#10b981';
        var titleColor = isAlert ? '#fca5a5' : '#6ee7b7';
        var icon = isAlert ? '⚠️' : '✅';

        toast.className = 'drop-toast-item';
        toast.style.cssText = 'pointer-events: auto; background: linear-gradient(135deg, rgba(20, 24, 33, 0.96) 0%, rgba(30, 35, 48, 0.96) 100%); border: 1px solid rgba(255,255,255,0.12); border-left: 4px solid ' + borderColor + '; border-radius: 12px; padding: 16px 18px; box-shadow: 0 16px 36px rgba(0,0,0,0.65), 0 0 20px ' + (isAlert ? 'rgba(239, 68, 68, 0.2)' : 'rgba(16, 185, 129, 0.2)') + '; backdrop-filter: blur(14px); -webkit-backdrop-filter: blur(14px); display: flex; flex-direction: column; gap: 8px; animation: dropToastSlideIn 0.35s cubic-bezier(0.16, 1, 0.3, 1) forwards; transition: all 0.35s ease; font-family: inherit;';

        toast.innerHTML = '<div style="display: flex; justify-content: space-between; align-items: flex-start; gap: 10px;">' +
            '<div style="display: flex; align-items: center; gap: 8px;">' +
                '<span style="font-size: 18px; line-height: 1;">' + icon + '</span>' +
                '<strong style="color: ' + titleColor + '; font-size: 14px; font-weight: 700; line-height: 1.3;">' + title + '</strong>' +
            '</div>' +
            '<button type="button" style="background: none; border: none; color: #94a3b8; font-size: 18px; cursor: pointer; padding: 0 4px; line-height: 1; transition: color 0.2s;" onmouseover="this.style.color=\'#fff\'" onmouseout="this.style.color=\'#94a3b8\'" onclick="this.closest(\'.drop-toast-item\').remove();">&times;</button>' +
        '</div>' +
        '<div style="color: #cbd5e1; font-size: 13px; line-height: 1.45;">' + message + '</div>' +
        '<div style="display: flex; align-items: center; gap: 6px; font-size: 11px; color: #94a3b8; margin-top: 4px; border-top: 1px solid rgba(255,255,255,0.08); padding-top: 6px;">' +
            '<span>🛡️</span>' +
            '<span>Segurança e Transparência CDC / Procon • Nenhuma cobrança indevida</span>' +
        '</div>';

        container.appendChild(toast);

        setTimeout(function() {
            toast.style.opacity = '0';
            toast.style.transform = 'translateX(100%)';
            setTimeout(function() {
                if (toast.parentNode) toast.parentNode.removeChild(toast);
            }, 350);
        }, duration);
    }
}

function handleStageBuyClick(event, btn, productId, slug, checkoutUrl, jsProdId, jsProdTitle, jsProdCat) {
    if (event) event.preventDefault();
    if (!btn || btn.getAttribute('data-sold-out') === '1' || btn._checkInProgress) {
        return false;
    }

    btn._checkInProgress = true;
    var origHtml = btn.innerHTML;
    btn.style.opacity = '0.75';
    btn.innerHTML = '<span>⏳ Checando...</span>';

    fetch(<?= json_encode($baseUrl . '/api/drop/check-availability', JSON_UNESCAPED_SLASHES) ?>, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' },
        body: JSON.stringify({ product_id: productId, slug: slug })
    })
    .then(function(r) { return r.json(); })
    .then(function(data) {
        btn._checkInProgress = false;
        if (data && data.available === false) {
            btn.setAttribute('data-sold-out', '1');
            btn.style.opacity = '0.55';
            btn.style.cursor = 'not-allowed';
            btn.style.background = '#334155';
            btn.style.color = '#cbd5e1';
            btn.innerHTML = '<span>Esgotado</span>';

            showDropToast({
                title: 'Produto Esgotado / Indisponível',
                message: data.message || 'O estoque deste produto se esgotou recentemente no fornecedor oficial. Para sua total segurança e transparência (CDC / Procon), nenhuma cobrança foi realizada no seu cartão ou Pix.',
                type: 'warning',
                duration: 8500
            });
            return;
        }

        btn.style.opacity = '1';
        btn.innerHTML = origHtml;
        if (window.trackDropAction) {
            window.trackDropAction(jsProdId, jsProdTitle, jsProdCat, 'buy_click');
        }
        window.location.href = checkoutUrl;
    })
    .catch(function() {
        btn._checkInProgress = false;
        btn.style.opacity = '1';
        btn.innerHTML = origHtml;
        if (window.trackDropAction) {
            window.trackDropAction(jsProdId, jsProdTitle, jsProdCat, 'buy_click');
        }
        window.location.href = checkoutUrl;
    });

    return false;
}
</script>
