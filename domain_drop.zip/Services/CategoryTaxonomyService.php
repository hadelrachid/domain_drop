<?php

declare(strict_types=1);

namespace DomainSystem\Plugins\domain_drop\Services;

use DomainSystem\Plugins\domain_drop\Contracts\CategoryTaxonomyInterface;

/**
 * Serviço de Taxonomia Canônica Oficial, Classificação Semântica e Filtros SQL (SOLID / SRP).
 * 
 * Totalmente alinhado às 548 categorias oficiais da AliExpress Open Platform (IOP SDK)
 * para produtos em território nacional brasileiro, sem invenção de termos.
 */
class CategoryTaxonomyService implements CategoryTaxonomyInterface
{
    // Categorias Oficiais alinhadas 1:1 com a AliExpress Open Platform
    public const CAT_TECH         = 'Eletrônicos & Telefonia';          // IDs 44, 509, 7
    public const CAT_MOBILE_TV    = 'Smartphones, TVs & Projetores 4K'; // IDs 509, 44, 7
    public const CAT_SMARTWATCH   = 'Relógios & Smartwatches';          // ID 1511
    public const CAT_HOME         = 'Casa, Iluminação & Eletro';        // IDs 15, 39, 6, 13
    public const CAT_TOOLS        = 'Ferramentas & Utilidades';         // IDs 1420, 30
    public const CAT_BEAUTY       = 'Beleza, Saúde & Maquiagem';        // IDs 66, 660103
    public const CAT_PETS         = 'Pet Shop';                         // ID 100006664 (Casa e jardim)
    public const CAT_AUTO         = 'Peças & Acessórios Automotivos';   // IDs 34, 201355758
    public const CAT_FASHION      = 'Roupas, Bolsas & Calçados';        // IDs 200000345, 200000343, 1524, 322
    public const CAT_FITNESS      = 'Moda Fitness, Leggings & Academia';// IDs 200000785, 200000349, 200000345, 200000780
    public const CAT_LINGERIE     = 'Roupa Íntima & Pijamas';           // ID 200574005 (feminina, masculina, pijamas)
    public const CAT_ADULT        = 'Novidades & Uso Especial';         // ID 200000532

    public function getCanonicalCategories(): array
    {
        return [
            self::CAT_TECH,
            self::CAT_MOBILE_TV,
            self::CAT_SMARTWATCH,
            self::CAT_HOME,
            self::CAT_TOOLS,
            self::CAT_BEAUTY,
            self::CAT_PETS,
            self::CAT_AUTO,
            self::CAT_FASHION,
            self::CAT_FITNESS,
            self::CAT_LINGERIE,
        ];
    }

    /**
     * Retorna os IDs numéricos oficiais correspondentes na árvore de categorias da AliExpress Open Platform.
     * Alinhado a categoria-e-atributos.pdf e dropshiper.pdf.
     *
     * @param string $category
     * @return array<int, int>
     */
    public function getAliExpressCategoryIds(string $category): array
    {
        $canonical = $this->normalizeCategory($category);
        return match ($canonical) {
            self::CAT_TECH       => [44, 509, 7],
            self::CAT_MOBILE_TV  => [509, 44, 7],
            self::CAT_SMARTWATCH => [1511],
            self::CAT_HOME       => [15, 39, 6],
            self::CAT_TOOLS      => [1420, 30],
            self::CAT_BEAUTY     => [66, 660103],
            self::CAT_PETS       => [100006664, 15],
            self::CAT_AUTO       => [34, 201355758],
            self::CAT_FASHION    => [200000345, 200000343, 200000346, 200000347, 200000344, 200000348, 1524, 322],
            self::CAT_FITNESS    => [200000785, 200000349, 200000345, 200000780],
            self::CAT_LINGERIE   => [200574005, 200000851, 200000858, 200000780, 200000778, 200000779, 200000781],
            default              => [44],
        };
    }

    /**
     * Retorna termos de busca otimizados em português para consulta no AliExpress.
     *
     * @param string $category
     * @return array<int, string>
     */
    public function getAliExpressSearchKeywords(string $category): array
    {
        $canonical = $this->normalizeCategory($category);
        return match ($canonical) {
            self::CAT_TECH       => [
                'fone bluetooth tws brasil',
                'carregador turbo tipo c 65w',
                'power bank inducao magnetico',
                'headset gamer microfone rgb',
                'caixa de som bluetooth potente',
                'fone conducao ossea corrida',
                'suporte articulado celular mesa',
                'cabo usb c carregamento rapido',
                'adaptador bluetooth transmissor audio'
            ],
            self::CAT_MOBILE_TV, 'Smartphones, TVs & Projetores 4K' => [
                'mini projetor hy300 4k',
                'projetor magcubic 4k android',
                'tv box android 4k',
                'smartphone poco x6 pro',
                'smartphone xiaomi redmi note',
                'projetor portatil wifi 4k',
                'smart tv box homologada',
                'celular android versao global'
            ],
            self::CAT_SMARTWATCH => [
                'smartwatch prova dagua nfc gps',
                'relogio inteligente monitor cardiaco',
                'smartwatch esportivo corrida fitness',
                'pulseira magnetica smartwatch',
                'smartwatch feminino elegante tela amoled',
                'relogio quartzo masculino executivo luxo',
                'smartwatch chamada bluetooth bateria longa'
            ],
            self::CAT_HOME       => [
                'fita led rgb inteligente tuya wifi',
                'lampada inteligente wifi alexa rgb',
                'sensor presenca inteligente automacao',
                'aspirador de po robo portatil recarregavel',
                'dispensador sabonete automatico sensor',
                'umidificador aromatizador ultrassonico led',
                'fechadura digital biometrica senha',
                'luz noturna sensor movimento sem fio'
            ],
            self::CAT_TOOLS      => [
                'alicate desencapador fios multifuncional',
                'jogo chave de precisao catraca bits',
                'parafusadeira eletrica sem fio recarregavel',
                'trena laser digital medidor distancia',
                'canivete tatico multifuncional sobrevivencia',
                'lanterna tatica led potente militar recarregavel',
                'soldador eletrico portatil precisao ferro'
            ],
            self::CAT_BEAUTY     => [
                'escova secadora alisadora modeladora 3 em 1',
                'paleta de sombras maquiagem profissional',
                'barbeador eletrico masculino aparador pelos',
                'depilador laser luz pulsada ipl indolor',
                'gloss labial efeito plump volume hidratante',
                'massageador facial eletrico gua sha lifting',
                'kit pinceis maquiagem profissional estojo',
                'espelho de maquiagem led recarregavel toque'
            ],
            self::CAT_PETS       => [
                'coleira led luminosa cachorro recarregavel usb',
                'bebedouro fonte automatica pet gato cachorro',
                'escova a vapor pet removedora pelos gatos caes',
                'brinquedo interativo inteligência gato pet',
                'cama nuvem calmante pelucia cachorro pet',
                'cortador de unhas pet com led iluminador',
                'tapete higienico impermeavel lavavel cachorro'
            ],
            self::CAT_AUTO       => [
                'suporte celular veicular carregador inducao magsafe',
                'transmissor bluetooth veicular fm usb aux',
                'aspirador automotivo portatil potente sem fio',
                'compressor de ar portatil eletrico pneus carro',
                'camera veicular dvr gravador painel seguranca',
                'fita led interna veicular sensor som rgb neon',
                'chaveiro veicular couro metal luxo logo'
            ],
            self::CAT_FASHION, 'Moda, Roupas & Vestuário' => [
                'vestido feminino casual verao elegante brasil',
                'camisa social masculina manga longa linho brasil',
                'camiseta basica 100 algodao unissex slim brasil',
                'jaqueta jeans masculina feminina oversize casual',
                'calca jeans feminina masculina skinny stretch brasil',
                'calca jogger streetwear cargo bolsos unissex',
                'jaqueta corta vento impermeavel capuz ciclismo',
                'conjunto moletom masculino feminino agasalho inverno',
                'blusa feminina casual verao elegante brasil',
                'tenis esportivo corrida caminhada respiravel leve',
                'bolsa feminina transversal tiracolo couro vintage',
                'mochila executiva impermeavel antifurto usb notebook'
            ],
            self::CAT_FITNESS, 'Moda Fitness, Leggings & Academia' => [
                'legging suplex feminina',
                'macacao fitness feminino',
                'conjunto academia feminino',
                'macaquinho fitness treino',
                'short suplex academia',
                'top fitness sustentacao',
                'calca legging empina bumbum',
                'body feminino canelado academia'
            ],
            self::CAT_LINGERIE, 'Moda Íntima, Lingeries & Pijamas' => [
                'conjunto lingerie renda floral sutiã calcinha luxo',
                'sutia sem costura sustentacao push up confortavel',
                'pijama feminino cetim seda camisola renda',
                'kit cuecas boxer modal sem costura respiravel',
                'meia calca termica translucida forrada peluciada',
                'kit calcinhas sem costura invisivel algodao',
                'espartilho modelador cinta feminina compressao'
            ],
            default              => ['eletronicos utilidades brasil'],
        };
    }

    public function toCommercialCategory(string $category): string
    {
        $raw = trim($category);
        if ($raw === '') {
            return 'Eletrônicos & Gadget';
        }

        $lower = mb_strtolower($raw, 'UTF-8');
        $clean = preg_replace('/[^\p{L}\p{N}\s&]/u', ' ', $lower) ?? $lower;

        // 0. Moda Fitness, Leggings & Academia (Precedência sobre Moda geral)
        if (str_contains($clean, 'fitness') || str_contains($clean, 'feetness') || str_contains($clean, 'legging') || str_contains($clean, 'academia') || str_contains($clean, 'suplex') || str_contains($clean, 'macaquinho') || str_contains($clean, 'macacao fitness') || str_contains($clean, 'macacão fitness')) {
            return 'Moda Fitness, Leggings & Academia';
        }

        // 0.1 Smartphones, TVs & Projetores 4K (Precedência sobre Eletrônicos gerais)
        if (str_contains($clean, 'smartphone') || str_contains($clean, 'celular') || str_contains($clean, 'projetor') || str_contains($clean, 'tv box') || str_contains($clean, 'smart tv') || str_contains($clean, 'xiaomi') || str_contains($clean, 'poco') || str_contains($clean, 'magcubic') || str_contains($clean, 'hy300')) {
            return 'Smartphones, TVs & Projetores 4K';
        }

        // 1. Moda Íntima e Lingeries
        if (str_contains($clean, 'lingerie') || str_contains($clean, 'intima') || str_contains($clean, 'íntima') || str_contains($clean, 'sutia') || str_contains($clean, 'sutiã') || str_contains($clean, 'calcinha') || str_contains($clean, 'cueca') || str_contains($clean, 'boxer') || str_contains($clean, 'pijama')) {
            return 'Moda Íntima, Lingeries & Pijamas';
        }

        // 2. Massagem & Bem-Estar Corporal
        if (str_contains($clean, 'massageador') || str_contains($clean, 'relaxamento') || str_contains($clean, 'miofascial') || str_contains($clean, 'massagem')) {
            return 'Beleza, Cuidados & Estilo';
        }

        // 3. Moda, Roupas & Vestuário
        if (str_contains($clean, 'roupa') || str_contains($clean, 'vestu') || str_contains($clean, 'calcado') || str_contains($clean, 'calçado') || str_contains($clean, 'casaco') || str_contains($clean, 'jaqueta') || str_contains($clean, 'calca') || str_contains($clean, 'calça') || str_contains($clean, 'camisa') || str_contains($clean, 'camiseta') || str_contains($clean, 'vestido') || str_contains($clean, 'blusa') || str_contains($clean, 'tenis') || str_contains($clean, 'tênis') || str_contains($clean, 'bolsa') || str_contains($clean, 'mochila') || str_contains($clean, 'carteira') || str_contains($clean, 'legging') || str_contains($clean, 'macacao') || str_contains($clean, 'macacão') || str_contains($clean, 'fitness') || str_contains($clean, 'academia') || str_contains($clean, 'moda')) {
            return 'Moda, Roupas & Vestuário';
        }

        // 4. Casa Inteligente & Organização
        if (str_contains($clean, 'casa') || str_contains($clean, 'ilumina') || str_contains($clean, 'eletro') || str_contains($clean, 'organiza') || str_contains($clean, 'decor')) {
            return 'Casa Inteligente & Organização';
        }

        // 5. Beleza, Cuidados & Estilo
        if (str_contains($clean, 'beleza') || str_contains($clean, 'saude') || str_contains($clean, 'saúde') || str_contains($clean, 'maquiagem') || str_contains($clean, 'cuidado') || str_contains($clean, 'estilo') || str_contains($clean, 'cabelo') || str_contains($clean, 'skincare')) {
            return 'Beleza, Cuidados & Estilo';
        }

        // 6. Ferramentas & Utilidades
        if (str_contains($clean, 'ferramenta') || str_contains($clean, 'utilidade') || str_contains($clean, 'alicate') || str_contains($clean, 'parafusadeira')) {
            return 'Ferramentas & Utilidades';
        }

        // 7. Pet Shop & Pets Virais
        if (str_contains($clean, 'pet') || str_contains($clean, 'cachorro') || str_contains($clean, 'gato') || str_contains($clean, 'cao') || str_contains($clean, 'cão')) {
            return 'Pet Shop & Pets Virais';
        }

        // 8. Acessórios para Veículos
        if (str_contains($clean, 'veiculo') || str_contains($clean, 'veículo') || str_contains($clean, 'auto') || str_contains($clean, 'carro') || str_contains($clean, 'moto')) {
            return 'Acessórios para Veículos';
        }

        // 9. Eletrônicos & Gadget
        return 'Eletrônicos & Gadget';
    }

    public function normalizeCategory(string $category): string
    {
        $raw = trim($category);
        if ($raw === '') {
            return self::CAT_TECH;
        }

        $lower = mb_strtolower($raw, 'UTF-8');
        $clean = preg_replace('/[^\p{L}\p{N}\s&]/u', ' ', $lower) ?? $lower;

        if (str_contains($clean, 'geral')) {
            return self::CAT_TOOLS;
        }

        // 0. Moda Fitness, Leggings & Academia (Precedência sobre Roupas em geral)
        if (str_contains($clean, 'fitness') || str_contains($clean, 'feetness') || str_contains($clean, 'legging') || str_contains($clean, 'academia') || str_contains($clean, 'suplex') || str_contains($clean, 'macaquinho') || str_contains($clean, 'macacao fitness') || str_contains($clean, 'macacão fitness')) {
            return self::CAT_FITNESS;
        }

        // 0.1 Smartphones, TVs & Projetores 4K (Precedência sobre Eletrônicos gerais)
        if (str_contains($clean, 'smartphone') || str_contains($clean, 'celular') || str_contains($clean, 'projetor') || str_contains($clean, 'tv box') || str_contains($clean, 'smart tv') || str_contains($clean, 'xiaomi') || str_contains($clean, 'poco') || str_contains($clean, 'magcubic') || str_contains($clean, 'hy300')) {
            return self::CAT_MOBILE_TV;
        }

        // 1. Roupa Íntima & Pijamas (ID 200574005)
        if (str_contains($clean, 'lingerie') || str_contains($clean, 'sutia') || str_contains($clean, 'sutiã') || str_contains($clean, 'calcinha') || str_contains($clean, 'intima') || str_contains($clean, 'íntima') || str_contains($clean, 'pijama') || str_contains($clean, 'cueca') || str_contains($clean, 'boxer') || str_contains($clean, 'espartilho') || str_contains($clean, 'corset')) {
            return self::CAT_LINGERIE;
        }

        // 2. Massagem & Bem-Estar Corporal
        if (str_contains($clean, 'massageador') || str_contains($clean, 'relaxamento') || str_contains($clean, 'miofascial') || str_contains($clean, 'massagem')) {
            return self::CAT_BEAUTY;
        }

        // 3. Roupas, Bolsas & Calçados (IDs 200000345, 200000343, 1524, 322)
        if (str_contains($clean, 'roupa') || str_contains($clean, 'vestuario') || str_contains($clean, 'vestuário') || str_contains($clean, 'casaco') || str_contains($clean, 'jaqueta') || str_contains($clean, 'mochila') || str_contains($clean, 'bolsa') || str_contains($clean, 'carteira') || str_contains($clean, 'sapato') || str_contains($clean, 'tenis') || str_contains($clean, 'tênis') || str_contains($clean, 'calcado') || str_contains($clean, 'calçado') || str_contains($clean, 'legging') || str_contains($clean, 'macacao') || str_contains($clean, 'macacão') || str_contains($clean, 'fitness') || str_contains($clean, 'academia') || (str_contains($clean, 'moda') && !str_contains($clean, 'intima') && !str_contains($clean, 'íntima'))) {
            return self::CAT_FASHION;
        }

        // 4. Pet Shop (ID 100006664)
        if (str_contains($clean, 'pet') || str_contains($clean, 'cachorro') || str_contains($clean, 'gato') || str_contains($clean, 'cao') || str_contains($clean, 'cão')) {
            return self::CAT_PETS;
        }

        // 5. Peças & Acessórios Automotivos (ID 34)
        if (str_contains($clean, 'veiculo') || str_contains($clean, 'veículo') || str_contains($clean, 'carro') || str_contains($clean, 'automotivo') || str_contains($clean, 'auto') || str_contains($clean, 'moto')) {
            return self::CAT_AUTO;
        }

        // 6. Ferramentas & Utilidades (ID 1420, 30)
        if (str_contains($clean, 'alicate') || str_contains($clean, 'ferramenta') || str_contains($clean, 'crimpador') || str_contains($clean, 'decapador') || str_contains($clean, 'chave de fenda') || str_contains($clean, 'utilidade') || str_contains($clean, 'segurança')) {
            return self::CAT_TOOLS;
        }

        // 7. Relógios & Smartwatches (ID 1511)
        if (str_contains($clean, 'smartwatch') || str_contains($clean, 'relogio') || str_contains($clean, 'relógio') || str_contains($clean, 'pulseira inteligente') || str_contains($clean, 'apple watch')) {
            return self::CAT_SMARTWATCH;
        }

        // 8. Beleza, Saúde & Maquiagem (ID 66, 660103)
        if (str_contains($clean, 'beleza') || str_contains($clean, 'cabelo') || str_contains($clean, 'pele') || str_contains($clean, 'secador') || str_contains($clean, 'escova') || str_contains($clean, 'saude') || str_contains($clean, 'saúde') || str_contains($clean, 'maquiagem') || str_contains($clean, 'batom')) {
            return self::CAT_BEAUTY;
        }

        // 9. Casa, Iluminação & Eletro (ID 15, 39, 6)
        if (str_contains($clean, 'casa') || str_contains($clean, 'led') || str_contains($clean, 'luminaria') || str_contains($clean, 'luminária') || str_contains($clean, 'lampada') || str_contains($clean, 'lâmpada') || str_contains($clean, 'iluminação') || str_contains($clean, 'eletro') || str_contains($clean, 'tuya')) {
            return self::CAT_HOME;
        }

        // 10. Eletrônicos & Telefonia (ID 44, 509, 7)
        return self::CAT_TECH;
    }

    public function classifyFromText(string $title, ?string $rawCategory = null): string
    {
        $t = mb_strtolower(trim($title), 'UTF-8');

        // 0. Moda Fitness, Leggings & Academia (Precedência alta sobre Moda geral)
        if (preg_match('/\b(legging|leggings|suplex|macaquinho|macaquinhos|macacão fitness|macacao fitness|conjunto academia|top fitness|calça suplex|calca suplex|bermuda fitness|empina bumbum|short suplex|fitness|feetness|academia)\b/iu', $t)) {
            return self::CAT_FITNESS;
        }

        // 0.1 Smartphones, TVs & Projetores 4K (Precedência sobre Eletrônicos gerais)
        if (preg_match('/\b(smartphone|smartphones|celular|celulares|projetor|projetores|magcubic|hy300|tv box|smart tv|poco x6|redmi note|xiaomi)\b/iu', $t)) {
            return self::CAT_MOBILE_TV;
        }

        // 1. Roupa Íntima & Pijamas (Precedência alta sobre Moda geral para evitar falso-positivo)
        if (preg_match('/\b(lingerie|sutiã|sutia|calcinha|calcinhas|bojo|push up|push-up|guipir|bralette|camisola|baby doll|pijama|pijamas|renda sexy|natalina sexy|meia-calça|meias-calça|meia calça|meias calça|meia calca|meia-calca|meia arrastão|meia arrastao|cueca|cuecas|boxer|slip|corpete|espartilho|espartilhos|corset|cinta modeladora|peças íntimas|pecas intimas|roupa íntima)\b/iu', $t)) {
            return self::CAT_LINGERIE;
        }

        // 2. Massagem, Fisioterapia & Bem-Estar Corporal
        if (preg_match('/\b(massageador|massageadora|relaxamento muscular|miofascial|pistola de massagem|almofada massageadora)\b/iu', $t)) {
            return self::CAT_BEAUTY;
        }

        // 3. Roupas, Bolsas & Calçados
        if (preg_match('/\b(casaco|casacos|jaqueta|jaquetas|corta-vento|corta vento|ciclismo|corrida secagem|impermeável masculino|capuz capa|moletom|calça|calca|camisa|camiseta|vestido|saia|bermuda|roupa|roupas|vestuário|vestuario|mochila|mochilas|bolsa|bolsas|carteira|carteiras|pochete|tênis|tenis|sapato|sapatos|sandália|sandalia|chinelo|chinelos|bota|botas|mocassim|calçado|calçados|calcado|calcados|meia|meias|invisível|invisivel|chaveiro|chaveiros|cinto|cintos|boné|bone|óculos|oculos)\b/iu', $t)) {
            return self::CAT_FASHION;
        }

        // 4. Pet Shop
        if (preg_match('/\b(pet|pets|cachorro|cachorros|cão|cães|gato|gatos|coleira|trela|fita led noite segurança|fibra ótica recarregável cães)\b/iu', $t)) {
            return self::CAT_PETS;
        }

        // 5. Peças & Acessórios Automotivos
        if (preg_match('/\b(veicular|veículo|veiculo|carro|automotivo|ventilação de ar|suporte celular carro|suporte automotivo|telemóvel com ventosa|suporte magnético 360|peças automotivas)\b/iu', $t)) {
            return self::CAT_AUTO;
        }

        // 6. Ferramentas & Utilidades
        if (preg_match('/\b(alicate|alicates|crimpador|decapador|desencapar fios|chaves de fenda|chave de fenda|catraca|ferramentas|ferramenta|chaves de precisão|bits)\b/iu', $t)) {
            return self::CAT_TOOLS;
        }

        // 7. Relógios & Smartwatches
        if (preg_match('/\b(smartwatch|smartwatches|relógio inteligente|relogio inteligente|relógio|relogio|apple watch|amazfit|aurafit|pulseira homem de ferro)\b/iu', $t)) {
            return self::CAT_SMARTWATCH;
        }

        // 8. Beleza, Saúde & Maquiagem
        if (preg_match('/\b(secador|escova secadora|escova alisadora|alisador|modelador de cabelo|cabelo|curling|barbeador|barba|depilador|maquiagem|facial|pele|batom|batons|gloss|rímel|rimel|delineador|base líquida|base liquida|corretivo|pó compacto|po compacto|paleta de sombras|paleta sombras|blush|pincel|pincéis|pinceis|esponja maquiagem|lip tint)\b/iu', $t)) {
            return self::CAT_BEAUTY;
        }

        // 9. Casa, Iluminação & Eletro
        if (preg_match('/\b(fita de led|fita led|rgbic|tuya|luminária|luminaria|lâmpada|lampada|barra de luz|monitor luzes|iluminação|teto|armário|quarto|cozinha|aspirador|eletrodoméstico|eletrodomestico|liquidificador portátil)\b/iu', $t)) {
            return self::CAT_HOME;
        }

        // 10. Se houver categoria bruta informada da API oficial, normaliza diretamente
        if ($rawCategory !== null && trim($rawCategory) !== '' && trim($rawCategory) !== 'Geral') {
            return $this->normalizeCategory($rawCategory);
        }

        return self::CAT_TECH;
    }

    public function buildSqlFilter(string $requestedCategory, array &$params): string
    {
        $raw = trim($requestedCategory);
        $lower = mb_strtolower($raw, 'UTF-8');
        $clean = preg_replace('/[^\p{L}\p{N}\s&]/u', ' ', $lower) ?? $lower;

        // 0. Filtro específico de Áudio & Fones (Prioridade alta antes de eletrônicos gerais)
        if ($clean === 'audio' || $clean === 'áudio' || str_starts_with($clean, 'fone') || str_contains($clean, 'ouvido') || str_contains($clean, 'headphone')) {
            return "(
                (
                    category IN ('Áudio', 'Audio', 'Fones Bluetooth TWS')
                    OR title LIKE '%Fone%'
                    OR title LIKE '%Tws%'
                    OR title LIKE '%Headphone%'
                    OR title LIKE '%Earphone%'
                    OR title LIKE '%Microfone%'
                )
                AND title NOT LIKE '%Smartwatch%'
                AND title NOT LIKE '%Relógio%'
                AND title NOT LIKE '%Pulseira%'
                AND title NOT LIKE '%Chave%'
                AND title NOT LIKE '%Reparo%'
            )";
        }

        // 0.1 Filtro específico de Celular / Smartphone
        if ($clean === 'celular' || $clean === 'smartphone' || $clean === 'celulares') {
            return "(
                category IN ('Telefones e telecomunicações', 'Celulares', 'Smartphones')
                OR title LIKE '%Celular%'
                OR title LIKE '%Telefone%'
                OR title LIKE '%Smartphone%'
            )";
        }

        // 0.2 Filtro específico de Moda Fitness & Leggings
        if (str_contains($clean, 'fitness') || str_contains($clean, 'feetness') || str_contains($clean, 'legging') || str_contains($clean, 'academia') || str_contains($clean, 'suplex') || str_contains($clean, 'macaquinho')) {
            return "(
                category IN ('Moda Fitness, Leggings & Academia', 'Moda Fitness', 'Fitness', 'Academia')
                OR category LIKE '%Fitness%'
                OR category LIKE '%Legging%'
                OR title LIKE '%Legging%'
                OR title LIKE '%Suplex%'
                OR title LIKE '%Macacão%'
                OR title LIKE '%Macacao%'
                OR title LIKE '%Macaquinho%'
                OR title LIKE '%Fitness%'
                OR title LIKE '%Academia%'
                OR title LIKE '%Empina Bumbum%'
            )";
        }

        // 0.3 Filtro específico de Smartphones, TVs & Projetores 4K
        if (str_contains($clean, 'projetor') || str_contains($clean, 'tv box') || str_contains($clean, 'smart tv') || str_contains($clean, 'poco') || str_contains($clean, 'magcubic') || str_contains($clean, 'hy300')) {
            return "(
                category IN ('Smartphones, TVs & Projetores 4K', 'Smartphones', 'Celulares', 'Projetores', 'TV Box')
                OR category LIKE '%Smartphone%'
                OR category LIKE '%Projetor%'
                OR category LIKE '%TV%'
                OR title LIKE '%Projetor%'
                OR title LIKE '%Magcubic%'
                OR title LIKE '%HY300%'
                OR title LIKE '%TV Box%'
                OR title LIKE '%Smartphone%'
                OR title LIKE '%Poco%'
                OR title LIKE '%Redmi Note%'
            )";
        }

        // 1. Roupa Íntima & Pijamas (ID 200574005)
        if (str_contains($clean, 'lingerie') || str_contains($clean, 'intima') || str_contains($clean, 'íntima') || str_contains($clean, 'pijama') || str_contains($clean, 'sutia') || str_contains($clean, 'sutiã') || str_contains($clean, 'meia calca') || str_contains($clean, 'meia calça') || str_contains($clean, 'cueca')) {
            return "(
                category IN ('Roupa Íntima & Pijamas', 'Roupa íntima', 'Moda Íntima, Lingeries & Pijamas', 'Moda Íntima', 'Lingeries', 'Lingerie')
                OR category LIKE '%Íntima%'
                OR category LIKE '%Intima%'
                OR category LIKE '%Lingerie%'
                OR title LIKE '%Lingerie%'
                OR title LIKE '%Sutiã%'
                OR title LIKE '%Sutia%'
                OR title LIKE '%Calcinha%'
                OR title LIKE '%Push Up%'
                OR title LIKE '%Push-Up%'
                OR title LIKE '%Pijama%'
                OR title LIKE '%Baby Doll%'
                OR title LIKE '%Renda Natalina%'
                OR title LIKE '%Meia-Calça%'
                OR title LIKE '%Meia Calça%'
                OR title LIKE '%Meia Calca%'
                OR title LIKE '%Arrastão%'
                OR title LIKE '%Arrastao%'
                OR title LIKE '%Cueca%'
                OR title LIKE '%Boxer%'
            )";
        }

        // 2. Massagem & Bem-Estar Corporal
        if (str_contains($clean, 'massageador') || str_contains($clean, 'massagem') || str_contains($clean, 'relaxamento') || str_contains($clean, 'miofascial')) {
            return "(
                category IN ('Beleza, Saúde & Maquiagem', 'Beleza, Cuidados & Estilo', 'Saúde e beleza')
                OR title LIKE '%Massageador%'
                OR title LIKE '%Relaxamento Muscular%'
                OR title LIKE '%Rolo De Massagem%'
            )";
        }

        // 3. Roupas, Bolsas & Calçados (IDs 200000345, 200000343, 1524, 322)
        if (str_contains($clean, 'roupa') || str_contains($clean, 'vestuario') || str_contains($clean, 'vestuário') || str_contains($clean, 'moda') || str_contains($clean, 'casaco') || str_contains($clean, 'jaqueta') || str_contains($clean, 'mochila') || str_contains($clean, 'bolsa') || str_contains($clean, 'carteira') || str_contains($clean, 'tenis') || str_contains($clean, 'tênis') || str_contains($clean, 'sapato') || str_contains($clean, 'calcado') || str_contains($clean, 'calçado')) {
            return "(
                (
                    category IN ('Roupas, Bolsas & Calçados', 'Moda, Roupas & Vestuário', 'Roupas femininas', 'Roupas masculinas', 'Bolsas e malas', 'Sapatos', 'Roupas', 'Vestuário', 'Moda')
                    OR (category LIKE '%Moda%' AND category NOT LIKE '%Íntima%' AND category NOT LIKE '%Intima%')
                    OR (category LIKE '%Roupa%' AND category NOT LIKE '%Íntima%' AND category NOT LIKE '%Intima%')
                    OR category LIKE '%Bolsa%'
                    OR category LIKE '%Sapato%'
                    OR category LIKE '%Calçado%'
                    OR title LIKE '%Casaco%'
                    OR title LIKE '%Jaqueta%'
                    OR title LIKE '%Corta-Vento%'
                    OR title LIKE '%Ciclismo%'
                    OR title LIKE '%Moletom%'
                    OR title LIKE '%Camisa%'
                    OR title LIKE '%Calça%'
                    OR title LIKE '%Mochila%'
                    OR title LIKE '%Bolsa%'
                    OR title LIKE '%Carteira%'
                    OR title LIKE '%Tênis%'
                    OR title LIKE '%Tenis%'
                    OR title LIKE '%Sapato%'
                    OR title LIKE '%Meia%'
                    OR title LIKE '%Chaveiro%'
                )
                AND title NOT LIKE '%Lingerie%'
                AND title NOT LIKE '%Sutiã%'
                AND title NOT LIKE '%Calcinha%'
                AND title NOT LIKE '%Meia-Calça%'
                AND title NOT LIKE '%Meia Calça%'
                AND title NOT LIKE '%Cueca%'
            )";
        }

        // 4. Pet Shop (ID 100006664)
        if (str_contains($clean, 'pet') || str_contains($clean, 'cachorro') || str_contains($clean, 'gato') || str_contains($clean, 'cao') || str_contains($clean, 'cão')) {
            return "(
                category IN ('Pet Shop', 'Pet Shop & Pets Virais')
                OR category LIKE '%Pet%'
                OR title LIKE '%Trela%'
                OR title LIKE '%Coleira%'
                OR title LIKE '%Cachorro%'
                OR title LIKE '% Cães%'
                OR title LIKE '% Cão %'
                OR title LIKE '% Cão,%'
                OR title LIKE '% Cão'
                OR title LIKE 'Cão %'
                OR title LIKE '%Gato%'
            )";
        }

        // 5. Peças & Acessórios Automotivos (ID 34)
        if (str_contains($clean, 'veiculo') || str_contains($clean, 'veículo') || str_contains($clean, 'carro') || str_contains($clean, 'automotivo') || str_contains($clean, 'auto') || str_contains($clean, 'moto') || str_contains($clean, 'peça')) {
            return "(
                category IN ('Peças & Acessórios Automotivos', 'Peças e acessórios automotivos', 'Acessórios para Veículos', 'Acessórios Auto')
                OR category LIKE '%Automotiv%'
                OR category LIKE '%Veículo%'
                OR category LIKE '%Veiculo%'
                OR category LIKE '%Auto%'
                OR title LIKE '%Veicular%'
                OR title LIKE '%Carro%'
                OR title LIKE '%Ventilação De Ar%'
                OR title LIKE '%Suporte Automotivo%'
                OR title LIKE '%Telemóvel Com Ventosa%'
            )";
        }

        // 6. Ferramentas & Utilidades (ID 1420, 30)
        if (str_contains($clean, 'alicate') || str_contains($clean, 'ferramenta') || str_contains($clean, 'crimpador') || str_contains($clean, 'decapador') || str_contains($clean, 'chave') || str_contains($clean, 'utilidade') || str_contains($clean, 'segurança')) {
            return "(
                category IN ('Ferramentas & Utilidades', 'Ferramentas', 'Segurança e proteção', 'Acessórios Virais & Ferramentas', 'Acessórios Virais')
                OR category LIKE '%Ferramenta%'
                OR category LIKE '%Alicate%'
                OR title LIKE '%Alicate%'
                OR title LIKE '%Crimpador%'
                OR title LIKE '%Decapador%'
                OR title LIKE '%Chave De Fenda%'
                OR title LIKE '%Chaves De Precisão%'
                OR title LIKE '%Catraca%'
            )";
        }

        // 7. Relógios & Smartwatches (ID 1511)
        if (str_contains($clean, 'smartwatch') || str_contains($clean, 'relogio') || str_contains($clean, 'relógio') || str_contains($clean, 'pulseira') || str_contains($clean, 'watch')) {
            return "(
                category IN ('Relógios & Smartwatches', 'Relógios', 'Smartwatches & Áudio', 'Smartwatches')
                OR category LIKE '%Relógio%'
                OR category LIKE '%Relogio%'
                OR category LIKE '%Smartwatch%'
                OR title LIKE '%Smartwatch%'
                OR title LIKE '%Relógio%'
                OR title LIKE '%Relogio%'
                OR title LIKE '%Apple Watch%'
                OR title LIKE '%Pulseira%'
            )";
        }

        // 8. Beleza, Saúde & Maquiagem (ID 66, 660103)
        if (str_contains($clean, 'beleza') || str_contains($clean, 'cabelo') || str_contains($clean, 'secador') || str_contains($clean, 'escova') || str_contains($clean, 'saude') || str_contains($clean, 'saúde') || str_contains($clean, 'cuidado') || str_contains($clean, 'maquiagem') || str_contains($clean, 'batom')) {
            return "(
                category IN ('Beleza, Saúde & Maquiagem', 'Beleza e saúde', 'Maquiagem', 'Beleza, Cuidados & Estilo', 'Saúde & Cuidados')
                OR category LIKE '%Beleza%'
                OR category LIKE '%Saúde%'
                OR category LIKE '%Saude%'
                OR category LIKE '%Maquiagem%'
                OR title LIKE '%Secador%'
                OR title LIKE '%Escova%'
                OR title LIKE '%Cabelo%'
                OR title LIKE '%Modelador%'
                OR title LIKE '%Barbeador%'
                OR title LIKE '%Maquiagem%'
                OR title LIKE '%Batom%'
                OR title LIKE '%Gloss%'
                OR title LIKE '%Rímel%'
                OR title LIKE '%Rimel%'
                OR title LIKE '%Paleta%'
                OR title LIKE '%Pincel%'
                OR title LIKE '%Pincéis%'
            )";
        }

        // 9. Casa, Iluminação & Eletro (ID 15, 39, 6, 13)
        if (str_contains($clean, 'casa') || str_contains($clean, 'led') || str_contains($clean, 'luminaria') || str_contains($clean, 'luminária') || str_contains($clean, 'lampada') || str_contains($clean, 'lâmpada') || str_contains($clean, 'iluminação') || str_contains($clean, 'eletro')) {
            return "(
                (
                    category IN ('Casa, Iluminação & Eletro', 'Casa e jardim', 'Luz e iluminação', 'Eletrodomésticos e Portáteis', 'Melhorias domésticas', 'Casa Inteligente & Organização', 'Casa Inteligente')
                    OR category LIKE '%Casa%'
                    OR category LIKE '%Iluminação%'
                    OR category LIKE '%Iluminacao%'
                    OR category LIKE '%Luz%'
                    OR category LIKE '%Eletro%'
                    OR title LIKE '%Led%'
                    OR title LIKE '%Luminária%'
                    OR title LIKE '%Luminaria%'
                    OR title LIKE '%Lâmpada%'
                    OR title LIKE '%Lampada%'
                    OR title LIKE '%Tuya%'
                    OR title LIKE '%Monitor%'
                )
                AND title NOT LIKE '%Trela%'
                AND title NOT LIKE '%Coleira%'
            )";
        }

        // 10. Eletrônicos & Telefonia (ID 44, 509, 7)
        if (str_contains($clean, 'eletronico') || str_contains($clean, 'eletrônico') || str_contains($clean, 'telefone') || str_contains($clean, 'telefonia') || str_contains($clean, 'computador') || str_contains($clean, 'tecnologia') || str_contains($clean, 'gadget') || str_contains($clean, 'audio') || str_contains($clean, 'áudio') || str_contains($clean, 'fone')) {
            return "(
                category IN ('Eletrônicos & Telefonia', 'Eletrônicos', 'Telefones e telecomunicações', 'Computador e escritório', 'Tecnologia & Gadgets', 'Eletrônicos & Gadget', 'Áudio', 'Audio', 'Fones Bluetooth TWS')
                OR category LIKE '%Eletrônic%'
                OR category LIKE '%Eletronic%'
                OR category LIKE '%Telefone%'
                OR category LIKE '%Computador%'
                OR category LIKE '%Tecnologia%'
                OR category LIKE '%Áudio%'
                OR category LIKE '%Audio%'
                OR title LIKE '%Projetor%'
                OR title LIKE '%Console%'
                OR title LIKE '%Power Bank%'
                OR title LIKE '%Carregador%'
                OR title LIKE '%Fone%'
                OR title LIKE '%Tws%'
                OR title LIKE '%Headphone%'
                OR title LIKE '%Earphone%'
                OR title LIKE '%Microfone%'
            )";
        }

        // Fallback genérico seguro
        $params[] = $raw;
        $params[] = '%' . $raw . '%';
        return "(category = ? OR category LIKE ?)";
    }
}
